-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: accsmarkets
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `_prisma_migrations`
--

DROP TABLE IF EXISTS `_prisma_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_prisma_migrations` (
  `id` varchar(36) NOT NULL,
  `checksum` varchar(64) NOT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `migration_name` varchar(255) NOT NULL,
  `logs` text DEFAULT NULL,
  `rolled_back_at` datetime(3) DEFAULT NULL,
  `started_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `applied_steps_count` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_prisma_migrations`
--

LOCK TABLES `_prisma_migrations` WRITE;
/*!40000 ALTER TABLE `_prisma_migrations` DISABLE KEYS */;
INSERT INTO `_prisma_migrations` VALUES ('22d10296-b483-4a59-88a2-a76e64bc28cc','e8491e979a8622a77c1adb9eb5f27a46589237a141916e3fcf5e15b8058355e7','2026-07-24 17:29:02.134','20260724024006_init','',NULL,'2026-07-24 17:29:02.134',0);
/*!40000 ALTER TABLE `_prisma_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `id` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `type` varchar(191) NOT NULL,
  `provider` varchar(191) NOT NULL,
  `providerAccountId` varchar(191) NOT NULL,
  `refresh_token` text DEFAULT NULL,
  `access_token` text DEFAULT NULL,
  `expires_at` int(11) DEFAULT NULL,
  `token_type` varchar(191) DEFAULT NULL,
  `scope` varchar(191) DEFAULT NULL,
  `id_token` text DEFAULT NULL,
  `session_state` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Account_provider_providerAccountId_key` (`provider`,`providerAccountId`),
  KEY `Account_userId_idx` (`userId`),
  CONSTRAINT `Account_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES ('cmrz6qkfu000ovs86xcj53lbb','cmrz6qkfk000mvs869uavrwi6','oauth','google','114072481391789654096',NULL,'ya29.a0ARGnu0Z0FFqaMMOTmcX6bcq9Fjj4MHBbvpxWxeHt_CPbFCFlahvVAEOalodzCuvoJl2vs6Tht52NarfjLNpDVNE1nTaI4jasYY49BMJtLh7AZx5hqmn41YPIQzjRox2S0Qrlu6ym5jvxoZKY41Se752FiQfAwq0BqWEHs_mZ2jSNLn0IcPeqg1LoE9I9AyzbfhLlRsuK3XgvFrijsuSIU9K7FMdrzei44EXn3cAuZ_ZkQmWKISq5hj6-W2XZsTWWPfDMSCGyglFl-u9QVaXeUYDdDu8XaCgYKAU8SARQSFQHGX2MiBlyLutlyCGNzq5ziiM0mXw0291',1784915965,'Bearer','https://www.googleapis.com/auth/userinfo.email openid https://www.googleapis.com/auth/userinfo.profile','eyJhbGciOiJSUzI1NiIsImtpZCI6IjMwZmUwZTIzYzRkNmUzNmM1MjU3N2IxZTJmZWZkMWFiYzM4ODk1ZGUiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI1NTAzMTcyNzIxMDktbThtdnUzYzdxcTQ2Mjh0YjVnMjRiZ3M3bjljZzNsYjkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI1NTAzMTcyNzIxMDktbThtdnUzYzdxcTQ2Mjh0YjVnMjRiZ3M3bjljZzNsYjkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMTQwNzI0ODEzOTE3ODk2NTQwOTYiLCJlbWFpbCI6ImFtZXJpY2FuaGlzdG9yeTkyMUBnbWFpbC5jb20iLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiYXRfaGFzaCI6ImNtWUU4SnkyQzlFb2lhSUN0STlrWXciLCJuYW1lIjoiQW1lcmljYW4gSGlzdG9yeSIsInBpY3R1cmUiOiJodHRwczovL2xoMy5nb29nbGV1c2VyY29udGVudC5jb20vYS9BQ2c4b2NJTmttVHFiNXFOb0plT1JDcTNOOFRoWkFEMnRFRjZFTGFnMndWTDdnVDVCRi03bDU4PXM5Ni1jIiwiZ2l2ZW5fbmFtZSI6IkFtZXJpY2FuIiwiZmFtaWx5X25hbWUiOiJIaXN0b3J5IiwiaWF0IjoxNzg0OTEyMzY2LCJleHAiOjE3ODQ5MTU5NjZ9.COguTHKpJ8EJV04UnHcivI8lhQ-nqrRl9bubHGOtk3S6CXbwpDO45XC99VfPNboSsbBtAld8an1XYR6FlBGCY2LmwKpyEOhlJfcyoY3Ey_gXS73KSuzyHgyEw4ZPSnx6Mw5flAahOrBN6n0VPvLZyncvbPSANFseBPk2jamMB-BOhiLZ9VmiefUDAEkAUl0wUpxmLWh3LVHVNxOEEdknLc3_w2vLHetWr0XEomrGmI3YYIMi0QTRJ5NmNmA5AvB_wsD6oTtb6hFHJhGs_0GntBQhsp5ywZ4NQH6yzx5pSawUcdRujNFALvfY8TGVBBbcxQkYCNcd1OFv69qFSxYZbg',NULL),('cmrzfl9ge000211ac2r6qw48g','cmrzfl9fa000011acdi1d6g3f','oauth','google','110543201269249490222',NULL,'ya29.a0ARGnu0ZilBuzcxGnIqXhc69w9jIeHPDjGneJ7oy_2aUVG9du1FZBbCMTDK5IBOubaFafpm9H-PlzbD7my0GwPEf6cWjVDLsDmeIG-9Jpk4n7-gRZ8rIRz-pDb1xJnm6-8F8ifo1I_gq5CfqIQVibhKy9BTTebCmfgVMf1vb8RQpfW2ZkVJVGEmEgeNKoGvcTeLKe-4UaCgYKAd8SARASFQHGX2MibFkWPGQrnEGYbfJzUjdtBw0206',1784930834,'Bearer','https://www.googleapis.com/auth/userinfo.email openid https://www.googleapis.com/auth/userinfo.profile','eyJhbGciOiJSUzI1NiIsImtpZCI6IjMwZmUwZTIzYzRkNmUzNmM1MjU3N2IxZTJmZWZkMWFiYzM4ODk1ZGUiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI2ODI2NDc5ODgyMjItZWM4bnFucWJwanNzOGdwcXVma3A2MTE1ODJncmJwbWouYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI2ODI2NDc5ODgyMjItZWM4bnFucWJwanNzOGdwcXVma3A2MTE1ODJncmJwbWouYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMTA1NDMyMDEyNjkyNDk0OTAyMjIiLCJlbWFpbCI6Inp1bHFhcm5haW5wZXJ2YWl6MjIyQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJhdF9oYXNoIjoieHFjQ1djY3MwNzNVRHVfN0FGS3lOUSIsIm5hbWUiOiJadWxxYXJuYWluIFBlcnZhaXoiLCJwaWN0dXJlIjoiaHR0cHM6Ly9saDMuZ29vZ2xldXNlcmNvbnRlbnQuY29tL2EvQUNnOG9jSV9EQklRaHJjNjVmUnZtYjN6ZndNbm1HSzNiU1BqdkI3cWg4RUlYZkJ4dU16MDRSR189czk2LWMiLCJnaXZlbl9uYW1lIjoiWnVscWFybmFpbiIsImZhbWlseV9uYW1lIjoiUGVydmFpeiIsImlhdCI6MTc4NDkyNzIzNSwiZXhwIjoxNzg0OTMwODM1fQ.GOMkqwSJAZ3zc6tV38Zw1mv_2DdVEEO-oVS8NXWbrd7-ck4gjo2YV6EtrC5GEDr1_kKNdJa1oNC1bV8zvgDfzLQMIM447OBikYzLZ552GIgyw_EA_SIgeU0p4zFuL3MG6sYVNDa3Rs5vd7TyBHuVxd9QFKb5MnXzavWrBxaIwoBG-Yz5ij2Q_4CLZU6GeB48KGRm0sPcXFa8DkxXhU3dOpPQwOlcq_XyEgI0lrhW9fhVoY6A7WxiGnzWY-JnuWv50xJXlDdUnAGD4hHYMk_cgtDO-FPz2rpcNLEAngNZmn3E8qpnOgDADcXBffyjt9uGQ7F949aIRZtgNyLo_gzUHg',NULL),('cmrzkv4p9000885gbhba6axtc','cmrzkv4or000685gbijzeqlym','oauth','google','116128061082742091190',NULL,'ya29.a0ARGnu0az2_6RhmasNcOfdon9OgbxmFzyo3oCaJQhWaUjS_9zzlxq08cg9JMlV7AS5EYr-ylahRZFZdvuGYjKlRGtWlCDAyZd8z3F3NWtwMH1XMQMg4XiJiU-a0uEv_ILcVXIqMTcA6jpeC8VngXjrA0r50Xuf0Z3wdBeYlKldlmlReq6YQgqHuQQXZQC8mLS4YjOr04aCgYKAQYSARESFQHGX2MigBRmRpFVAmoT_vFAMOMeLg0206',1784939693,'Bearer','https://www.googleapis.com/auth/userinfo.profile openid https://www.googleapis.com/auth/userinfo.email','eyJhbGciOiJSUzI1NiIsImtpZCI6IjMwZmUwZTIzYzRkNmUzNmM1MjU3N2IxZTJmZWZkMWFiYzM4ODk1ZGUiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI2ODI2NDc5ODgyMjItZWM4bnFucWJwanNzOGdwcXVma3A2MTE1ODJncmJwbWouYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI2ODI2NDc5ODgyMjItZWM4bnFucWJwanNzOGdwcXVma3A2MTE1ODJncmJwbWouYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMTYxMjgwNjEwODI3NDIwOTExOTAiLCJlbWFpbCI6ImNtY2VsbW9AZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF0X2hhc2giOiJqb2JHR01pdEtPNUFzRlpKYmYxQS1BIiwibmFtZSI6IkNoZXJ5bCBDb2ZmZXkiLCJwaWN0dXJlIjoiaHR0cHM6Ly9saDMuZ29vZ2xldXNlcmNvbnRlbnQuY29tL2EvQUNnOG9jS3pxcWwwcHZONm1SbmtTSzBEOWFKQ1lOa3RfMFNrS0VhUmtUMHNaa0t2X3dfb1BJV29xdz1zOTYtYyIsImdpdmVuX25hbWUiOiJDaGVyeWwiLCJmYW1pbHlfbmFtZSI6IkNvZmZleSIsImlhdCI6MTc4NDkzNjA5NCwiZXhwIjoxNzg0OTM5Njk0fQ.K5hVCNu-2UeVstRm-JdLlxmX1krXSxwGz3Awf-YHIyO3k0HBCJAXdxpYKHSFs_NETYsoLzuojhKvOudG-ewZQ-NKi2-cqphu83uV-_8WkHW8ZoR1WXT2Tz9Sf8xqxAIMNPQiZTT1yBvCa6MmCPEKOlLW-9-mCfXOn4AMwsnnO-6ZA_uwgINjrxABZlizUMpyzAd9LILJiU58rYYjeXTOZVTVrA7vLHuCDX8JqWAlh6oP2bJ_BGObI3DFi2DF2QDJtE7rEwQNoD80-UClKhxhGMdPt5rDqJDzJ-o4JfhKNc_EALUcon_G5tHI926oCJ_TiV8MxboqZKucz57l4J07zA',NULL);
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `activesession`
--

DROP TABLE IF EXISTS `activesession`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activesession` (
  `id` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `userAgent` text DEFAULT NULL,
  `ip` varchar(191) DEFAULT NULL,
  `lastSeenAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `ActiveSession_userId_idx` (`userId`),
  CONSTRAINT `ActiveSession_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activesession`
--

LOCK TABLES `activesession` WRITE;
/*!40000 ALTER TABLE `activesession` DISABLE KEYS */;
INSERT INTO `activesession` VALUES ('cmrz6qmp0000qvs86isdjripw','cmrz6qkfk000mvs869uavrwi6','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','92.96.11.80','2026-07-24 19:54:02.599','2026-07-24 16:59:29.508'),('cmrze1vk100018pscjioy1749','cmrz6qkfk000mvs869uavrwi6','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','92.96.11.80','2026-07-24 20:28:43.268','2026-07-24 20:24:11.521'),('cmrzfla6s000411ace8r1lsav','cmrzfl9fa000011acdi1d6g3f','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/139.0.7258.76 Mobile/15E148 Safari/604.1','92.96.11.80','2026-07-24 21:25:16.903','2026-07-24 21:07:16.564'),('cmrzfy7ux00016vh4y7kovvrm','cmrz6qkfk000mvs869uavrwi6','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','92.96.11.80','2026-07-25 20:58:23.684','2026-07-24 21:17:20.073'),('cmrzjqki3000185gbxs17iqh9','cmrzfl9fa000011acdi1d6g3f','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/139.0.7258.76 Mobile/15E148 Safari/604.1','92.96.11.80','2026-07-25 00:00:08.305','2026-07-24 23:03:21.676'),('cmrzkv5j5000a85gbryjnbgka','cmrzkv4or000685gbijzeqlym','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','92.96.11.80','2026-07-25 14:28:13.864','2026-07-24 23:34:55.169'),('cmrzt6oid0001xukmzx0rcyc2','cmrzfl9fa000011acdi1d6g3f','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/139.0.7258.76 Mobile/15E148 Safari/604.1','92.96.11.80','2026-07-25 03:40:11.240','2026-07-25 03:27:49.910'),('cms0i1eup0001kdvf23f1nqcx','cmrzkv4or000685gbijzeqlym','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','92.96.11.80','2026-07-25 15:03:34.513','2026-07-25 15:03:34.513'),('cms0i1euu0003kdvfebsw29t8','cmrzkv4or000685gbijzeqlym','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','92.96.11.80','2026-07-25 20:58:24.196','2026-07-25 15:03:34.517'),('cms0mjrqp0001o2f2gvcscuao','cmrzfl9fa000011acdi1d6g3f','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/139.0.7258.76 Mobile/15E148 Safari/604.1','87.201.88.132','2026-07-25 17:09:49.489','2026-07-25 17:09:49.489'),('cms0momty0003o2f2va5a7f9b','cmrzfl9fa000011acdi1d6g3f','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/139.0.7258.76 Mobile/15E148 Safari/604.1','92.96.11.80','2026-07-25 17:13:36.511','2026-07-25 17:13:36.406'),('cms11ocuq0003huv75qwt2k6l','cmrz6qkfk000mvs869uavrwi6','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','92.96.11.80','2026-07-26 01:42:00.706','2026-07-26 00:13:17.714'),('cms141s5z00014z90lnjvxov0','cmrzfl9fa000011acdi1d6g3f','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/139.0.7258.76 Mobile/15E148 Safari/604.1','92.96.11.80','2026-07-26 01:20:40.477','2026-07-26 01:19:43.319'),('cms1qmk7r00034z90ivab5874','cmrz6qkfk000mvs869uavrwi6','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','92.96.11.80','2026-07-26 19:15:03.991','2026-07-26 11:51:44.343'),('cms2bajki0001mi177q2jitvk','cmrz6qkfk000mvs869uavrwi6','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','92.96.11.80','2026-07-26 22:56:36.711','2026-07-26 21:30:15.569');
/*!40000 ALTER TABLE `activesession` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `activityevent`
--

DROP TABLE IF EXISTS `activityevent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activityevent` (
  `id` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `type` varchar(191) NOT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`metadata`)),
  `isPublic` tinyint(1) NOT NULL DEFAULT 0,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `ActivityEvent_userId_createdAt_idx` (`userId`,`createdAt`),
  KEY `ActivityEvent_isPublic_createdAt_idx` (`isPublic`,`createdAt`),
  CONSTRAINT `ActivityEvent_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activityevent`
--

LOCK TABLES `activityevent` WRITE;
/*!40000 ALTER TABLE `activityevent` DISABLE KEYS */;
INSERT INTO `activityevent` VALUES ('cmrz8i0if0006dv3lyse32wr3','cmrz6qkfk000mvs869uavrwi6','listing.created','{\"listingId\":\"cmrz8i0i20004dv3lh7s06ldy\",\"title\":\"Islamic YouTube Shorts Channel | 1,150 Subscribers | 65% Engagement\",\"platform\":\"YOUTUBE\"}',1,'2026-07-24 17:48:46.744'),('cms0psn3r0009o2f24bl09hnv','cmrz6qkfk000mvs869uavrwi6','listing.created','{\"listingId\":\"cms0psn380007o2f2tm7cufq3\",\"title\":\"Established YouTube Channel Since 2020 – Music, Entertainment & 4K Content\",\"platform\":\"YOUTUBE\"}',1,'2026-07-25 18:40:42.231');
/*!40000 ALTER TABLE `activityevent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `adminauditlog`
--

DROP TABLE IF EXISTS `adminauditlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adminauditlog` (
  `id` varchar(191) NOT NULL,
  `adminId` varchar(191) NOT NULL,
  `action` varchar(191) NOT NULL,
  `targetType` varchar(191) NOT NULL,
  `targetId` varchar(191) NOT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `AdminAuditLog_adminId_idx` (`adminId`),
  KEY `AdminAuditLog_targetType_targetId_idx` (`targetType`,`targetId`),
  CONSTRAINT `AdminAuditLog_adminId_fkey` FOREIGN KEY (`adminId`) REFERENCES `user` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adminauditlog`
--

LOCK TABLES `adminauditlog` WRITE;
/*!40000 ALTER TABLE `adminauditlog` DISABLE KEYS */;
INSERT INTO `adminauditlog` VALUES ('cmrxycpdq0054pnrd1ijvgc0s','cmrxycp3p0005pnrdzzoawa9h','listing.approve','Listing','cmrxycp4z000lpnrdt79w6do9',NULL,'2026-07-16 20:16:56.702'),('cmrxycpdv0056pnrd7u55q2qg','cmrxycp3p0005pnrdzzoawa9h','listing.approve','Listing','cmrxycp52000zpnrd0dsuiwkb',NULL,'2026-07-19 20:16:56.702'),('cmrxycpdz0058pnrdxjj7dqyz','cmrxycp3p0005pnrdzzoawa9h','listing.approve','Listing','cmrxycp51000npnrdp2n8i6w8',NULL,'2026-07-20 20:16:56.702'),('cmrxycpe2005apnrdy1h9ovm6','cmrxycp3p0005pnrdzzoawa9h','listing.approve','Listing','cmrxycp51000rpnrdxcubskk3',NULL,'2026-07-18 20:16:56.702'),('cmrxycpe6005cpnrdijzgcp0g','cmrxycp3p0005pnrdzzoawa9h','listing.approve','Listing','cmrxycp52000upnrdpmcyyqru',NULL,'2026-07-21 20:16:56.702'),('cmrxycpea005epnrd56ak45ng','cmrxycp3p0005pnrdzzoawa9h','deposit.confirm','CryptoWallet','manual',NULL,'2026-07-13 20:16:56.702'),('cmrxycped005gpnrdpubz6vwq','cmrxycp3p0005pnrdzzoawa9h','user.badge.award','User','cmrxycp4b000bpnrdeuregzht','\"{\\\"badge\\\":\\\"POWER_SELLER\\\"}\"','2026-05-24 20:16:56.702'),('cmrxycpeh005ipnrdxcqvoqkt','cmrxycp3p0005pnrdzzoawa9h','escrow.verify','Escrow','cmrxycp63001fpnrdttzl6qlg',NULL,'2026-07-20 20:16:56.702'),('cmry4ul670002j7hujrxfjut7','cmrxycp3p0005pnrdzzoawa9h','update_pricing','SubscriptionPlan','bulk','{\"planCount\":4}','2026-07-23 23:18:48.752'),('cmry8yhv10001gkze4sa2ex2o','cmrxycp3p0005pnrdzzoawa9h','enable_maintenance_mode','PlatformSettings','singleton','{\"maintenanceTitle\":\"Maintenance in Progress\",\"maintenanceEndTime\":null}','2026-07-24 01:13:49.549'),('cmry8yijn0003gkzebkvezbox','cmrxycp3p0005pnrdzzoawa9h','disable_maintenance_mode','PlatformSettings','singleton','{\"maintenanceTitle\":\"Maintenance in Progress\",\"maintenanceEndTime\":null}','2026-07-24 01:13:50.435'),('cmrz90knj0002bwrjw11ifx51','cmrxycp3p0005pnrdzzoawa9h','listing.approve','Listing','cmrz8i0i20004dv3lh7s06ldy','{}','2026-07-24 18:03:12.656'),('cmrz96xkx0006aa1oz7w6y3kw','cmrxycp3w0007pnrdv1agkll3','listing.approve','Listing','cmrz8i0i20004dv3lh7s06ldy',NULL,'2026-07-24 18:08:09.345'),('cmrzj6z140002vaxnu2elaqsu','cmrxycp3w0007pnrdv1agkll3','listing.approve','Listing','cmrz8i0i20004dv3lh7s06ldy',NULL,'2026-07-24 22:48:07.384'),('cms0psszc000co2f22ugbfdav','cmrxycp3w0007pnrdv1agkll3','listing.approve','Listing','cms0psn380007o2f2tm7cufq3',NULL,'2026-07-25 18:40:49.848'),('cms2bcjrl0007mi17bh2v1l8i','cmrxycp3w0007pnrdv1agkll3','bank_deposit.reject','BankTransferOrder','cms2bbf170004mi17l1wl6v99','{}','2026-07-26 21:31:49.138');
/*!40000 ALTER TABLE `adminauditlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcement`
--

DROP TABLE IF EXISTS `announcement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcement` (
  `id` varchar(191) NOT NULL,
  `type` enum('INFO','WARNING','SUCCESS') NOT NULL DEFAULT 'INFO',
  `message` text NOT NULL,
  `linkUrl` varchar(191) DEFAULT NULL,
  `linkText` varchar(191) DEFAULT NULL,
  `targetAudience` enum('ALL','BUYER','SELLER') NOT NULL DEFAULT 'ALL',
  `isActive` tinyint(1) NOT NULL DEFAULT 1,
  `startsAt` datetime(3) DEFAULT NULL,
  `endsAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcement`
--

LOCK TABLES `announcement` WRITE;
/*!40000 ALTER TABLE `announcement` DISABLE KEYS */;
INSERT INTO `announcement` VALUES ('cmry9baws0008gkzebioq2y4j','INFO','New feature: Bank transfer deposits are now available! Deposit via wire transfer with lower fees.','http://localhost:3000/dashboard/wallet/deposit','Try it out!','ALL',1,NULL,NULL,'2026-07-24 01:23:47.068','2026-07-24 01:23:47.068');
/*!40000 ALTER TABLE `announcement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apikey`
--

DROP TABLE IF EXISTS `apikey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apikey` (
  `id` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `keyHash` varchar(191) NOT NULL,
  `keyPrefix` varchar(191) NOT NULL,
  `scopes` varchar(191) NOT NULL DEFAULT 'read',
  `lastUsedAt` datetime(3) DEFAULT NULL,
  `expiresAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `revokedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ApiKey_keyHash_key` (`keyHash`),
  KEY `ApiKey_userId_idx` (`userId`),
  CONSTRAINT `ApiKey_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apikey`
--

LOCK TABLES `apikey` WRITE;
/*!40000 ALTER TABLE `apikey` DISABLE KEYS */;
/*!40000 ALTER TABLE `apikey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appinstallation`
--

DROP TABLE IF EXISTS `appinstallation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appinstallation` (
  `id` varchar(191) NOT NULL,
  `appId` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `grantedScopes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`grantedScopes`)),
  `installedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `AppInstallation_appId_userId_key` (`appId`,`userId`),
  KEY `AppInstallation_userId_idx` (`userId`),
  CONSTRAINT `AppInstallation_appId_fkey` FOREIGN KEY (`appId`) REFERENCES `applisting` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AppInstallation_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appinstallation`
--

LOCK TABLES `appinstallation` WRITE;
/*!40000 ALTER TABLE `appinstallation` DISABLE KEYS */;
/*!40000 ALTER TABLE `appinstallation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `applisting`
--

DROP TABLE IF EXISTS `applisting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `applisting` (
  `id` varchar(191) NOT NULL,
  `developerId` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `description` text NOT NULL,
  `iconUrl` varchar(191) DEFAULT NULL,
  `websiteUrl` varchar(191) DEFAULT NULL,
  `apiScopesRequested` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`apiScopesRequested`)),
  `status` enum('DRAFT','SUBMITTED','APPROVED','REJECTED') NOT NULL DEFAULT 'DRAFT',
  `installCount` int(11) NOT NULL DEFAULT 0,
  `rejectionReason` text DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `AppListing_developerId_idx` (`developerId`),
  KEY `AppListing_status_idx` (`status`),
  CONSTRAINT `AppListing_developerId_fkey` FOREIGN KEY (`developerId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applisting`
--

LOCK TABLES `applisting` WRITE;
/*!40000 ALTER TABLE `applisting` DISABLE KEYS */;
/*!40000 ALTER TABLE `applisting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auctionbid`
--

DROP TABLE IF EXISTS `auctionbid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auctionbid` (
  `id` varchar(191) NOT NULL,
  `listingId` varchar(191) NOT NULL,
  `bidderId` varchar(191) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `placedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `AuctionBid_listingId_placedAt_idx` (`listingId`,`placedAt`),
  KEY `AuctionBid_bidderId_idx` (`bidderId`),
  CONSTRAINT `AuctionBid_bidderId_fkey` FOREIGN KEY (`bidderId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AuctionBid_listingId_fkey` FOREIGN KEY (`listingId`) REFERENCES `listing` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auctionbid`
--

LOCK TABLES `auctionbid` WRITE;
/*!40000 ALTER TABLE `auctionbid` DISABLE KEYS */;
/*!40000 ALTER TABLE `auctionbid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banktransferorder`
--

DROP TABLE IF EXISTS `banktransferorder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banktransferorder` (
  `id` varchar(191) NOT NULL,
  `referenceId` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `bankAccountId` varchar(191) NOT NULL,
  `amountUsd` decimal(10,2) NOT NULL,
  `feeUsd` decimal(10,2) NOT NULL,
  `totalDue` decimal(10,2) NOT NULL,
  `amountReceived` decimal(10,2) DEFAULT NULL,
  `status` enum('PENDING','SENT','VERIFIED','REJECTED','EXPIRED') NOT NULL DEFAULT 'PENDING',
  `senderName` varchar(191) DEFAULT NULL,
  `proofImageUrl` varchar(191) DEFAULT NULL,
  `sentAt` datetime(3) DEFAULT NULL,
  `verifiedAt` datetime(3) DEFAULT NULL,
  `rejectedAt` datetime(3) DEFAULT NULL,
  `rejectionReason` text DEFAULT NULL,
  `adminNotes` text DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `BankTransferOrder_referenceId_key` (`referenceId`),
  KEY `BankTransferOrder_userId_status_idx` (`userId`,`status`),
  KEY `BankTransferOrder_status_createdAt_idx` (`status`,`createdAt`),
  KEY `BankTransferOrder_bankAccountId_fkey` (`bankAccountId`),
  CONSTRAINT `BankTransferOrder_bankAccountId_fkey` FOREIGN KEY (`bankAccountId`) REFERENCES `platformbankaccount` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `BankTransferOrder_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banktransferorder`
--

LOCK TABLES `banktransferorder` WRITE;
/*!40000 ALTER TABLE `banktransferorder` DISABLE KEYS */;
INSERT INTO `banktransferorder` VALUES ('cms2bbf170004mi17l1wl6v99','BT-06621790','cmrz6qkfk000mvs869uavrwi6','cms1ymvyl000425dwgtimp17c',10.00,2.00,12.00,NULL,'REJECTED',NULL,NULL,NULL,NULL,'2026-07-26 21:31:49.128',NULL,NULL,'2026-07-26 21:30:56.347','2026-07-26 21:31:49.133');
/*!40000 ALTER TABLE `banktransferorder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blogautomationlog`
--

DROP TABLE IF EXISTS `blogautomationlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blogautomationlog` (
  `id` varchar(191) NOT NULL,
  `prompt` text NOT NULL,
  `postId` varchar(191) DEFAULT NULL,
  `success` tinyint(1) NOT NULL,
  `error` text DEFAULT NULL,
  `tokensIn` int(11) DEFAULT NULL,
  `tokensOut` int(11) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blogautomationlog`
--

LOCK TABLES `blogautomationlog` WRITE;
/*!40000 ALTER TABLE `blogautomationlog` DISABLE KEYS */;
INSERT INTO `blogautomationlog` VALUES ('cmry9lsy1000igkze4t3l8agb','How to safely buy a YouTube channel on AccsMarkets - Complete Guide 2025',NULL,0,'Gemini API error 404: {\n  \"error\": {\n    \"code\": 404,\n    \"message\": \"models/gemini-1.5-pro is not found for API version v1beta, or is not supported for generateContent. Call ModelService.ListModels to see the list of avai',0,0,'2026-07-24 01:31:57.001'),('cmry9m1eo000kgkzezdtpr7k2','How to safely buy a YouTube channel on AccsMarkets - Complete Guide 2025',NULL,0,'OpenAI API error 429: {\n    \"error\": {\n        \"message\": \"You exceeded your current quota, please check your plan and billing details. For more information on this error, read the docs: https://platform.openai.com/docs/gu',0,0,'2026-07-24 01:32:07.968'),('cmry9m90b000mgkzej3tjw6k2','How to safely buy a YouTube channel on AccsMarkets - Complete Guide 2025',NULL,0,'OpenAI API error 429: {\n    \"error\": {\n        \"message\": \"You exceeded your current quota, please check your plan and billing details. For more information on this error, read the docs: https://platform.openai.com/docs/gu',0,0,'2026-07-24 01:32:17.820'),('cmry9oqik0001nb1tvs2mh59p','How to safely buy a YouTube channel on AccsMarkets in 2025',NULL,0,'OpenAI API error 429: {\n    \"error\": {\n        \"message\": \"You exceeded your current quota, please check your plan and billing details. For more information on this error, read the docs: https://platform.openai.com/docs/gu',0,0,'2026-07-24 01:34:13.821'),('cmry9r9z70003nb1t1k4xpozz','How to safely buy a YouTube channel on AccsMarkets in 2025',NULL,0,'Gemini API error 404: {\n  \"error\": {\n    \"code\": 404,\n    \"message\": \"models/gemini-1.5-pro is not found for API version v1beta, or is not supported for generateContent. Call ModelService.ListModels to see the list of avai',0,0,'2026-07-24 01:36:12.356'),('cmry9u1i40005nb1t788zwvq0','How to safely buy a YouTube channel on AccsMarkets in 2025',NULL,0,'Grok API error 403: {\"code\":\"permission-denied\",\"error\":\"Your team 7b1657c8-84ec-49d1-99c3-727a1d931bcd has either used all available credits or reached its monthly spending limit. To continue making API requests, please',0,0,'2026-07-24 01:38:21.341'),('cmry9x4fa0007nb1tmpawelae','How to safely buy a YouTube channel on AccsMarkets in 2025',NULL,0,'Bad control character in string literal in JSON at position 387 (line 4 column 71)',212,1723,'2026-07-24 01:40:45.094'),('cmry9za7t0009nb1ts39h7z3v','How to safely buy a YouTube channel on AccsMarkets in 2025',NULL,0,'Expected property name or \'}\' in JSON at position 2 (line 1 column 3)',212,1403,'2026-07-24 01:42:25.913'),('cmrya0511000bnb1t1wslsyqb','How to safely buy a YouTube channel on AccsMarkets in 2025',NULL,0,'Expected property name or \'}\' in JSON at position 2 (line 1 column 3)',212,1670,'2026-07-24 01:43:05.845'),('cmrya1chg000enb1tksf5zmv2','How to safely buy a YouTube channel on AccsMarkets in 2025','cmrya1ch6000dnb1totgc2y09',1,NULL,212,1502,'2026-07-24 01:44:02.164'),('cmrz9azmk000aaa1o2kcukpr1','How to safely buy a YouTube channel on AccsMarkets in 2026',NULL,0,'Expected property name or \'}\' in JSON at position 2 (line 1 column 3)',212,1389,'2026-07-24 18:11:18.620'),('cmrza2x3b000daa1orpvcvhys','How to safely buy a YouTube channel on AccsMarkets in 2026','cmrza2x2e000caa1o3cl4wxzx',1,NULL,212,1635,'2026-07-24 18:33:01.703'),('cmrzcw3ol000113trzscnsr4h','How to safely buy a YouTube channel on AccsMarkets in 2026',NULL,0,'Gemini API error 429: {\n  \"error\": {\n    \"code\": 429,\n    \"message\": \"You exceeded your current quota, please check your plan and billing details. For more information on this error, head to: https://ai.google.dev/gemini-a',0,0,'2026-07-24 19:51:42.502'),('cmrzcws6p000313trpj6xepor','How to safely buy a YouTube channel on AccsMarkets in 2026',NULL,0,'Gemini API error 429: {\n  \"error\": {\n    \"code\": 429,\n    \"message\": \"You exceeded your current quota, please check your plan and billing details. For more information on this error, head to: https://ai.google.dev/gemini-a',0,0,'2026-07-24 19:52:14.257'),('cmrzcwsyi000513tr8d204ef2','How to safely buy a YouTube channel on AccsMarkets in 2026',NULL,0,'Gemini API error 429: {\n  \"error\": {\n    \"code\": 429,\n    \"message\": \"You exceeded your current quota, please check your plan and billing details. For more information on this error, head to: https://ai.google.dev/gemini-a',0,0,'2026-07-24 19:52:15.258'),('cms0kag0j000bx3alforf8ulh','A Beginner\'s Guide to Buying Instagram Accounts on AccsMarkets',NULL,0,'Expected property name or \'}\' in JSON at position 2 (line 1 column 3)',209,1539,'2026-07-25 16:06:35.156'),('cms0knl2g00029hg401n5u3tw','A Beginner\'s Guide to Buying Instagram Accounts on AccsMarkets','cms0knl1r00019hg4uzmgzp0n',1,NULL,209,1602,'2026-07-25 16:16:48.232'),('cms0knuu700049hg4oa6109uy','5 Tips for Sellers to Increase Their Social Media Account\'s Value',NULL,0,'No JSON in AI response.',209,2048,'2026-07-25 16:17:00.895'),('cms0knzre00079hg4xhgw3hvk','5 Tips for Sellers to Increase Their Social Media Account\'s Value','cms0knzr100069hg41joq1xay',1,NULL,209,1052,'2026-07-25 16:17:07.274'),('cms1soxqx000g4z90v87n5dv3','The Importance of Account Safety: How to Protect Your Social Media Investments','cms1soxq9000f4z90lmv2muz7',1,NULL,282,601,'2026-07-26 12:49:34.426'),('cms1sp77k000j4z90pys5dpth','The Ultimate Guide to Buying TikTok Accounts: Trends and Pricing Strategies','cms1sp775000i4z900kqyv89k',1,NULL,282,754,'2026-07-26 12:49:46.689'),('cms1spgi1000l4z90ycwg1ecm','How to Avoid Scams When Buying or Selling Social Media Accounts Online',NULL,0,'Unexpected token \'H\', ...\"{\"title\": How to Avo\"... is not valid JSON',282,805,'2026-07-26 12:49:58.729'),('cms1spjre000n4z90qx1j3lkg','How to Avoid Scams When Buying or Selling Social Media Accounts Online',NULL,0,'Unexpected token \'H\', ...\"{\"title\": How to Avo\"... is not valid JSON',282,753,'2026-07-26 12:50:02.955'),('cms1spou5000p4z90lu85txbn','How to Avoid Scams When Buying or Selling Social Media Accounts Online',NULL,0,'Unexpected token \'H\', ...\"{\"title\": How to Avo\"... is not valid JSON',282,836,'2026-07-26 12:50:09.534'),('cms1t9kkd000125dwlcahpwb2','How to Avoid Scams When Buying or Selling Social Media Accounts Online',NULL,0,'Unexpected token \'H\', ...\"{\"title\": How to Avo\"... is not valid JSON',282,934,'2026-07-26 13:05:37.117'),('cms1t9xlu000325dwc751us97','The Rise of Niche Discord Servers: How to Buy or Sell a Server on AccsMarkets',NULL,0,'Unexpected token \'T\', ...\"{\"title\": The Rise o\"... is not valid JSON',289,996,'2026-07-26 13:05:54.019'),('cms2bpbhh000cmi17e2l293k0','Success Story: How One Buyer Turned a Purchased YouTube Channel into a Million-View Sensation','cms2bpbgy000bmi171chjcwgq',1,NULL,289,982,'2026-07-26 21:41:44.933'),('cms2bpngr000emi17hopcv77f','Avoiding Scams on Social Media Marketplaces: Red Flags and Best Practices for Buyers and Sellers',NULL,0,'Unexpected token \'A\', ...\"{\"title\": Avoiding S\"... is not valid JSON',288,776,'2026-07-26 21:42:00.459'),('cms2bpqet000hmi17nrxhv6mh','Avoiding Scams on Social Media Marketplaces: Red Flags and Best Practices for Buyers and Sellers','cms2bpqei000gmi17fhsw469r',1,NULL,288,740,'2026-07-26 21:42:04.277'),('cms2bq1hw000jmi17dnxg1ndz','AccsMarkets Marketplace Trends: Insights into the Most In-Demand Social Media Accounts and Niches',NULL,0,'Unexpected token \'A\', ...\"{\"title\": AccsMarket\"... is not valid JSON',289,757,'2026-07-26 21:42:18.644'),('cms2bq3q4000mmi17uwfno842','AccsMarkets Marketplace Trends: Insights into the Most In-Demand Social Media Accounts and Niches','cms2bq3pp000lmi17jt22r352',1,NULL,289,714,'2026-07-26 21:42:21.532');
/*!40000 ALTER TABLE `blogautomationlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blogpost`
--

DROP TABLE IF EXISTS `blogpost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blogpost` (
  `id` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `title` varchar(191) NOT NULL,
  `excerpt` text NOT NULL,
  `content` mediumtext NOT NULL,
  `coverImage` varchar(191) DEFAULT NULL,
  `status` enum('DRAFT','PUBLISHED','ARCHIVED') NOT NULL DEFAULT 'DRAFT',
  `authorId` varchar(191) DEFAULT NULL,
  `tags` varchar(191) DEFAULT NULL,
  `viewCount` int(11) NOT NULL DEFAULT 0,
  `isAiGen` tinyint(1) NOT NULL DEFAULT 0,
  `publishedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `BlogPost_slug_key` (`slug`),
  KEY `BlogPost_status_publishedAt_idx` (`status`,`publishedAt`),
  KEY `BlogPost_slug_idx` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blogpost`
--

LOCK TABLES `blogpost` WRITE;
/*!40000 ALTER TABLE `blogpost` DISABLE KEYS */;
INSERT INTO `blogpost` VALUES ('cmrya1ch6000dnb1totgc2y09','how-to-safely-buy-a-youtube-channel-on-accsmarkets-in-2025','How to Safely Buy a YouTube Channel on AccsMarkets in 2025','Safely purchasing a YouTube channel requires careful consideration of several factors, including the channel\'s content, audience engagement, and monetization potential, to ensure a successful and profitable acquisition.','<h2>Introduction to Buying a YouTube Channel</h2><p>Purchasing a YouTube channel can be a great way to establish an online presence, tap into an existing audience, and monetize content. However, it\'s essential to approach this process with caution to avoid potential pitfalls. In this article, we\'ll guide you through the steps to safely buy a YouTube channel on AccsMarkets in 2025.</p><h2>Research and Due Diligence</h2><p>Before making a purchase, it\'s crucial to conduct thorough research on the channel you\'re interested in. This includes:</p><ul><li>Reviewing the channel\'s content to ensure it aligns with your brand and values</li><li>Analyzing the channel\'s audience engagement, including views, likes, and comments</li><li>Evaluating the channel\'s monetization potential, including ads, sponsorships, and merchandise sales</li><li>Checking the channel\'s history, including any previous controversies or strikes</li></ul><p>AccsMarkets provides a platform for buyers to connect with sellers, but it\'s still important to do your own research and verify the information provided.</p><h3>Verifying Channel Ownership and Authenticity</h3><p>To ensure a smooth transaction, it\'s vital to verify the channel\'s ownership and authenticity. This can be done by:</p><ul><li>Checking the channel\'s YouTube verification status</li><li>Verifying the seller\'s identity and contact information</li><li>Reviewing the channel\'s analytics and performance data</li></ul><p>AccsMarkets offers a secure and transparent platform for buying and selling social media accounts, including YouTube channels.</p><h2>Understanding the Purchase Process</h2><p>Once you\'ve found a channel you\'re interested in and have completed your research, it\'s time to make an offer. The purchase process typically involves:</p><ul><li>Negotiating a price with the seller</li><li>Completing a payment through a secure payment gateway</li><li>Transferring ownership of the channel</li></ul><p>AccsMarkets provides a secure and convenient payment system, ensuring a smooth transaction for both buyers and sellers.</p><h2>Post-Purchase Considerations</h2><p>After completing the purchase, it\'s essential to consider the next steps, including:</p><ul><li>Updating the channel\'s branding and content to align with your own</li><li>Engaging with the existing audience and building a community</li><li>Optimizing the channel for monetization and growth</li></ul><p>AccsMarkets offers resources and support to help buyers succeed with their new channel.</p><h2>Conclusion</h2><p>Purchasing a YouTube channel can be a great way to establish an online presence and tap into an existing audience. By following the steps outlined in this article and using a reputable marketplace like AccsMarkets, you can safely buy a YouTube channel and set yourself up for success. If you\'re ready to take your online presence to the next level, visit AccsMarkets today to browse our selection of available YouTube channels and start growing your audience.</p>',NULL,'PUBLISHED',NULL,'YouTube channel, social media marketing, online presence, AccsMarkets, buying a YouTube channel',8,1,'2026-07-24 01:44:38.662','2026-07-24 01:44:02.154','2026-07-26 03:49:59.076'),('cmrza2x2e000caa1o3cl4wxzx','how-to-safely-buy-a-youtube-channel-on-accsmarkets-in-2026','How to Safely Buy a YouTube Channel on AccsMarkets in 2026','Safely purchasing a YouTube channel requires careful consideration of several factors, including the channel\'s reputation, content quality, and audience engagement, which is why choosing a reputable marketplace like AccsMarkets is crucial.','How to Safely Buy a YouTube Channel on AccsMarkets in 2026<br><br>Safely purchasing a YouTube channel requires careful consideration of several factors, including the channel\'s reputation, content quality, and audience engagement, which is why choosing a reputable marketplace like AccsMarkets is crucial.<h2>Introduction to Buying a YouTube Channel</h2><p>Purchasing a YouTube channel can be a great way to jumpstart your online presence, tap into an existing audience, and monetize your content. However, it\'s essential to approach this process with caution to avoid potential pitfalls. In this article, we\'ll guide you through the process of safely buying a YouTube channel on AccsMarkets in 2026.</p><h2>Why Buy a YouTube Channel?</h2><p>There are several reasons why you might want to buy a YouTube channel. Perhaps you\'re looking to expand your reach, increase your influence, or monetize your content more effectively. Whatever your motivations, buying a YouTube channel can be a smart move – as long as you do your research and choose a reputable seller.</p><h3>Benefits of Buying a YouTube Channel</h3><p>Some of the benefits of buying a YouTube channel include:</p><ul><li>Established audience: A pre-existing audience can save you time and effort in building your brand from scratch.</li><li>Content library: A YouTube channel often comes with a library of existing content, which can be a valuable asset.</li><li>Monetization opportunities: A established YouTube channel can provide a steady stream of income through ads, sponsorships, and merchandise sales.</li></ul><h2>How to Safely Buy a YouTube Channel on AccsMarkets</h2><p>When buying a YouTube channel on AccsMarkets, it\'s essential to follow a few key steps to ensure a safe and successful transaction. These include:</p><h3>Researching the Seller</h3><p>Before making a purchase, research the seller to ensure they are reputable and trustworthy. Check their feedback, ratings, and reviews from previous buyers to get an idea of their reliability.</p><h3>Verifying the Channel\'s Authenticity</h3><p>Verify the channel\'s authenticity by checking its views, engagement, and content quality. Be wary of channels with suspiciously high view counts or engagement metrics that seem unrealistic.</p><h3>Checking the Channel\'s Monetization Status</h3><p>Check the channel\'s monetization status to ensure it is eligible for ads and other revenue streams. A channel that is not monetized may not be worth as much as one that is.</p><h2>What to Look for in a YouTube Channel</h2><p>When evaluating a YouTube channel for purchase, there are several factors to consider. These include:</p><ul><li>Content quality: Is the content high-quality, engaging, and relevant to your target audience?</li><li>Audience engagement: Is the audience active and engaged, with high levels of likes, comments, and shares?</li><li>Reputation: Does the channel have a good reputation, with minimal controversy or negative feedback?</li></ul><h2>Conclusion</h2><p>In conclusion, buying a YouTube channel on AccsMarkets can be a great way to jumpstart your online presence and tap into an existing audience. By following the steps outlined in this article and doing your research, you can safely and successfully purchase a YouTube channel that meets your needs and goals. If you\'re ready to take your online presence to the next level, head over to AccsMarkets today to browse our selection of high-quality YouTube channels for sale.</p>',NULL,'PUBLISHED',NULL,'YouTube channel, AccsMarkets, social media, online presence, content creation',10,1,'2026-07-24 18:33:01.662','2026-07-24 18:33:01.670','2026-07-26 08:49:44.418'),('cms0knl1r00019hg4uzmgzp0n','a-beginner-s-guide-to-buying-instagram-accounts-on-accsmarkets','A Beginner\'s Guide to Buying Instagram Accounts on AccsMarkets','Buying an Instagram account can be a great way to kickstart your online presence, and AccsMarkets makes it easy to find and purchase the perfect account for your needs','A Beginner\'s Guide to Buying Instagram Accounts on AccsMarkets\nBuying an Instagram account can be a great way to kickstart your online presence, but it can also be a daunting task, especially for beginners. \n<h2>Introduction to Buying Instagram Accounts</h2>\n<p>Instagram has become one of the most popular social media platforms, with over a billion active users. Having a strong presence on Instagram can be beneficial for individuals, businesses, and organizations looking to increase their online visibility, engage with their audience, and drive sales. However, building an Instagram account from scratch can take time, effort, and resources. This is where buying an Instagram account comes in – it can provide a shortcut to establishing a strong online presence.</p>\n<h2>Benefits of Buying an Instagram Account</h2>\n<p>There are several benefits to buying an Instagram account, including:</p>\n<ul>\n<li>Established audience: Buying an Instagram account gives you access to an existing audience that is already engaged with the content.</li>\n<li>Saved time: Building an Instagram account from scratch can take months or even years. Buying an account saves you time and effort.</li>\n<li>Increased credibility: An established Instagram account can give you instant credibility and trust with your audience.</li>\n<li>Better reach: An account with a large following can help you reach a wider audience and increase your online visibility.</li>\n</ul>\n<h2>Things to Consider When Buying an Instagram Account</h2>\n<p>Before buying an Instagram account, there are several things you should consider, including:</p>\n<ul>\n<li>Niche: Make sure the account is in a niche that is relevant to your business or brand.</li>\n<li>Engagement: Check the account\'s engagement rates to ensure that the audience is active and engaged.</li>\n<li>Content quality: Review the content on the account to ensure it is high-quality and aligns with your brand values.</li>\n<li>Average watch time: If the account has videos, check the average watch time to ensure that the audience is watching the content until the end.</li>\n</ul>\n<h2>How to Buy an Instagram Account on AccsMarkets</h2>\n<p>AccsMarkets is a social media account marketplace that makes it easy to buy and sell Instagram accounts. Here\'s how to buy an Instagram account on AccsMarkets:</p>\n<ul>\n<li>Sign up for an account: Create an account on AccsMarkets and verify your email address.</li>\n<li>Browse accounts: Browse the available Instagram accounts on AccsMarkets and filter by niche, price, and other criteria.</li>\n<li>Review account details: Review the details of the account you\'re interested in, including the niche, engagement rates, and content quality.</li>\n<li>Make an offer: Make an offer on the account or purchase it at the listed price.</li>\n</ul>\n<h3>After the Purchase</h3>\n<p>After buying an Instagram account on AccsMarkets, you\'ll need to take a few steps to ensure a smooth transition. This includes:</p>\n<ul>\n<li>Changing the account password and email address</li>\n<li>Updating the account profile and bio</li>\n<li>Reviewing and responding to comments and messages</li>\n</ul>\n<p>By following these steps and considering the factors mentioned above, you can find and purchase the perfect Instagram account for your needs on AccsMarkets. With a strong Instagram presence, you can increase your online visibility, engage with your audience, and drive sales. So why wait? Head over to AccsMarkets today and start browsing the available Instagram accounts for sale.</p>',NULL,'PUBLISHED',NULL,'Instagram accounts, social media marketing, online presence, AccsMarkets',4,1,'2026-07-25 16:16:48.200','2026-07-25 16:16:48.208','2026-07-26 03:49:55.979'),('cms0knzr100069hg41joq1xay','5-tips-for-sellers-to-increase-their-social-media-account-s-value','5 Tips for Sellers to Increase Their Social Media Account\'s Value','Increasing the value of a social media account can be a great way for sellers to get a better price when they decide to sell, and with the right strategies, it\'s achievable.','<h2>Introduction to Social Media Account Valuation</h2><p>Social media accounts have become a valuable commodity in the digital age, with many individuals and businesses looking to buy and sell established accounts. As a seller, it\'s essential to understand what makes your account valuable and how to increase its worth. In this article, we\'ll explore five tips to help you boost your social media account\'s value and attract more buyers.</p><h2>Tip 1: Increase Your Follower Count</h2><p>A large and engaged follower count is one of the most critical factors in determining the value of a social media account. To increase your follower count, focus on creating high-quality content that resonates with your target audience. Use relevant hashtags, tag other users, and engage with your followers by responding to comments and messages. You can also consider collaborating with other users or influencers in your niche to reach a broader audience.</p><h3>Benefits of a Large Follower Count</h3><ul><li>Increased credibility and authority in your niche</li><li>Improved engagement and reach for your content</li><li>Higher chances of attracting brands and sponsors</li></ul><h2>Tip 2: Improve Your Content Quality</h2><p>High-quality content is essential for attracting and retaining followers. Invest in good camera equipment, editing software, and take the time to plan and produce engaging content. Use a mix of content types, such as videos, photos, and stories, to keep your audience interested. Consistency is key, so make sure to post content regularly and maintain a consistent aesthetic.</p><h3>Content Creation Tips</h3><ul><li>Use good lighting and sound quality</li><li>Invest in a content calendar to plan and organize your posts</li><li>Engage with your followers by asking questions and requesting feedback</li></ul><h2>Tip 3: Engage with Your Audience</h2><p>Engagement is critical for building a loyal follower base and increasing the value of your social media account. Respond to comments and messages promptly, and use social listening to stay on top of industry trends and conversations. Host giveaways, contests, or Q&amp;A sessions to encourage audience participation and build a community around your account.</p><h3>Benefits of Engagement</h3><ul><li>Increased loyalty and retention among followers</li><li>Improved brand reputation and credibility</li><li>Higher chances of attracting brands and sponsors</li></ul><h2>Tip 4: Leverage Your Niche or Expertise</h2><p>Establishing yourself as an expert in a specific niche or industry can significantly increase the value of your social media account. Focus on creating content that showcases your expertise and provides value to your followers. Collaborate with other experts or influencers in your niche to build relationships and expand your reach.</p><h3>Niche-Specific Tips</h3><ul><li>Stay up-to-date with industry trends and news</li><li>Participate in online communities and forums related to your niche</li><li>Offer exclusive content or services to your followers</li></ul><h2>Tip 5: Keep Your Account Active and Up-to-Date</h2><p>A dormant or outdated social media account can quickly lose value. Make sure to regularly post content, update your profile, and engage with your followers. Keep your account secure by using strong passwords and enabling two-factor authentication.</p><h3>Account Maintenance Tips</h3><ul><li>Use a content calendar to plan and organize your posts</li><li>Monitor your account\'s performance using analytics tools</li><li>Stay up-to-date with the latest social media trends and best practices</li></ul><p>By following these five tips, you can increase the value of your social media account and attract more buyers. If you\'re looking to sell your account, consider listing it on AccsMarkets, a reputable social media account marketplace. With AccsMarkets, you can reach a wide audience of potential buyers and get a fair price for your account. Sign up today and start selling your social media account!</p>',NULL,'PUBLISHED',NULL,'social media, social media accounts, social media marketing, online presence, digital marketing',9,1,'2026-07-25 16:17:07.255','2026-07-25 16:17:07.262','2026-07-26 03:49:52.803'),('cms1soxq9000f4z90lmv2muz7','the-importance-of-account-safety-how-to-protect-your-social-media-investments','The Importance of Account Safety: How to Protect Your Social Media Investments','Protecting your social media accounts is crucial to safeguarding your online presence and investments','<h2>Introduction to Social Media Account Safety</h2><p>Social media has become an integral part of our lives, and for many, it\'s also a significant investment. Whether you\'re a business, influencer, or individual, your social media accounts are valuable assets that require protection. As the number of social media users continues to grow, so does the risk of account compromise, hacking, and other forms of cyber threats.</p><h2>Why Account Safety Matters</h2><p>Account safety is essential for several reasons. Firstly, a compromised account can lead to financial losses, damage to your reputation, and loss of sensitive information. Moreover, if your account is hacked, you may lose access to your account, and recovering it can be a tedious and time-consuming process.</p><p>Additionally, social media platforms have strict policies against account hacking and abuse. If your account is found to be compromised, it may be suspended or terminated, resulting in the loss of your online presence and investments.</p><h2>Best Practices for Account Safety</h2><p>To protect your social media accounts, follow these best practices:</p><ul><li>Use strong and unique passwords for each account</li><li>Enable two-factor authentication (2FA) whenever possible</li><li>Be cautious of phishing scams and suspicious links</li><li>Keep your account information up to date and monitor your account activity regularly</li><li>Avoid using public computers or public Wi-Fi to access your accounts</li></ul><h2>Additional Security Measures</h2><p>In addition to the best practices mentioned above, you can take extra security measures to protect your accounts. These include:</p><ul><li>Using a password manager to generate and store complex passwords</li><li>Enabling account alerts and notifications to stay informed of any suspicious activity</li><li>Using a virtual private network (VPN) to secure your internet connection</li><li>Regularly updating your operating system, browser, and other software to ensure you have the latest security patches</li></ul><h2>Conclusion</h2><p>In conclusion, account safety is a critical aspect of social media management. By following best practices and taking extra security measures, you can protect your social media investments and safeguard your online presence. At AccsMarkets, we understand the importance of account safety and provide a secure marketplace for buying and selling social media accounts. If you\'re looking to invest in social media or protect your existing accounts, visit AccsMarkets today and take the first step towards securing your online presence.</p>',NULL,'PUBLISHED',NULL,'social media account safety, account security, online protection, cybersecurity, AccsMarkets',4,1,'2026-07-26 12:49:34.394','2026-07-26 12:49:34.401','2026-07-26 13:02:27.750'),('cms1sp775000i4z900kqyv89k','the-ultimate-guide-to-buying-tiktok-accounts-trends-and-pricing-strategies','The Ultimate Guide to Buying TikTok Accounts: Trends and Pricing Strategies','Learn how to buy TikTok accounts with the right trends and pricing strategies to boost your online presence and business growth','<h2>Introduction to Buying TikTok Accounts</h2><p>With over a billion active users, TikTok has become a crucial platform for businesses, influencers, and individuals to establish their online presence. Buying TikTok accounts can be a strategic move to gain instant popularity, increase brand awareness, and reach a wider audience. However, it\'s essential to understand the trends and pricing strategies involved in buying TikTok accounts to make an informed decision.</p><h2>Why Buy TikTok Accounts?</h2><p>There are several reasons why buying TikTok accounts can be beneficial for your online presence and business growth. Some of the key advantages include:</p><ul><li>Instant popularity and credibility</li><li>Increased brand awareness and reach</li><li>Access to a targeted audience</li><li>Cost-effective marketing strategy</li><li>Improved engagement and conversion rates</li></ul><h2>Trends in Buying TikTok Accounts</h2><p>The demand for buying TikTok accounts is on the rise, and several trends are shaping the market. Some of the current trends include:</p><ul><li>Niche-specific accounts: Buyers are looking for accounts with a specific niche or theme to target their desired audience.</li><li>High-quality content: Accounts with high-quality, engaging content are in high demand.</li><li>Authenticity: Buyers are seeking accounts with authentic and genuine content to build trust with their audience.</li><li>Engagement: Accounts with high engagement rates, such as likes, comments, and followers, are more valuable.</li></ul><h2>Pricing Strategies for Buying TikTok Accounts</h2><p>The pricing of TikTok accounts varies widely depending on several factors, including the number of followers, engagement rate, content quality, and niche. Here are some general pricing strategies to consider:</p><ul><li>Followers: Accounts with a large number of followers (100k+) can cost anywhere from $500 to $5,000 or more.</li><li>Engagement rate: Accounts with high engagement rates (2%+) can command a premium price, ranging from $1,000 to $10,000 or more.</li><li>Content quality: Accounts with high-quality, engaging content can cost more than those with low-quality content.</li><li>Niche: Accounts in high-demand niches, such as beauty or gaming, can be more expensive than those in less popular niches.</li></ul><h2>Where to Buy TikTok Accounts</h2><p>When it comes to buying TikTok accounts, it\'s crucial to choose a reputable marketplace that offers authentic and high-quality accounts. AccsMarkets is a trusted platform that provides a wide range of TikTok accounts for sale, with varying prices and specifications to suit your needs.</p><h2>Conclusion</h2><p>In conclusion, buying TikTok accounts can be a smart move to boost your online presence and business growth. By understanding the current trends and pricing strategies, you can make an informed decision and find the right account that meets your needs and budget. If you\'re looking to buy TikTok accounts, visit AccsMarkets today and explore our wide range of options to take your online presence to the next level.</p>',NULL,'PUBLISHED',NULL,'TikTok accounts, social media marketing, online presence, business growth, buying TikTok accounts, AccsMarkets',5,1,'2026-07-26 12:49:46.672','2026-07-26 12:49:46.674','2026-07-26 22:42:35.307'),('cms2bpbgy000bmi171chjcwgq','success-story-how-one-buyer-turned-a-purchased-youtube-channel-into-a-million-vi','Success Story: How One Buyer Turned a Purchased YouTube Channel into a Million-View Sensation','A buyer turned a purchased YouTube channel into a million-view sensation, showcasing the potential of buying established social media accounts','<h2>Introduction to a Million-View Success Story</h2><p>In the vast and ever-evolving landscape of social media, the quest for online presence and influence is more competitive than ever. For many, building a successful YouTube channel from scratch can be a daunting task, requiring significant time, effort, and sometimes, a bit of luck. However, there\'s an alternative strategy that\'s gaining traction: buying an existing YouTube channel. This approach can give buyers a head start, providing them with an already established audience and content foundation. One such success story is of a buyer who, through AccsMarkets, a leading social media account marketplace, acquired a YouTube channel and transformed it into a million-view sensation.</p><h2>Background: The Purchase</h2><p>The buyer, who wished to remain anonymous, was a social media enthusiast with a keen eye for content creation and marketing. Recognizing the potential of YouTube as a platform for reaching a broad audience, they decided to explore the option of buying an existing channel rather than starting from scratch. After researching various marketplaces, they found AccsMarkets, which offered a wide range of social media accounts, including YouTube channels, at competitive prices. The buyer was particularly drawn to one channel that had a niche audience but showed signs of untapped potential.</p><h3>Why This Channel?</h3><p>The channel in question had been created several years ago and had a consistent, albeit small, following. The content was of good quality, focusing on a specific niche that, while not overly popular, had a dedicated fan base. The buyer saw an opportunity to not only maintain the existing audience but also to expand it by introducing new content ideas, improving production quality, and engaging more actively with viewers. The decision to purchase this channel was based on several key factors, including:</p><ul><li>Existing audience engagement, which indicated a loyal fan base.</li><li>Potential for growth within the niche, as there was room for more content and better engagement strategies.</li><li>Affordability, as the price of the channel was within the buyer\'s budget and offered a good return on investment potential.</li></ul><h2>Post-Purchase Strategy</h2><p>After acquiring the channel, the buyer embarked on a comprehensive strategy to revamp and grow the channel. This involved:</p><ul><li>Content refresh: Introducing new formats, themes, and production techniques to make the content more appealing and diverse.</li><li>Engagement boost: Regularly interacting with the audience through comments, live streams, and social media platforms to foster a sense of community.</li><li>Marketing and promotion: Utilizing SEO techniques, collaborations with other creators, and paid advertising to increase the channel\'s visibility and reach a broader audience.</li><li>Consistency and patience: Regularly posting high-quality content and being patient, as building a large following takes time.</li></ul><h3>Results and Impact</h3><p>The results of these efforts were nothing short of remarkable. Within a year, the channel\'s viewership skyrocketed, surpassing the million-view mark. The engagement metrics also saw a significant increase, with more likes, comments, and shares than ever before. The success of the channel not only fulfilled the buyer\'s goals but also provided a platform for creating meaningful content that resonated with a large and dedicated audience.</p><h2>Conclusion: Buying Success</h2><p>The story of this buyer and their million-view YouTube channel serves as a testament to the potential of purchasing established social media accounts. It highlights the importance of strategy, dedication, and the right foundation—provided in this case by the channel acquired through AccsMarkets. For those looking to make their mark on social media, considering the purchase of an existing account can be a savvy move, offering a shortcut to establishing a presence and audience.</p><p>Whether you\'re a seasoned content creator or an aspiring social media influencer, AccsMarkets offers a unique opportunity to find and buy the perfect social media account to match your goals and ambitions. With a wide range of accounts available, from YouTube channels to Instagram profiles, you can find the ideal starting point for your online journey. Visit AccsMarkets today and discover how buying a social media account can be the first step towards your own success story.</p>',NULL,'PUBLISHED',NULL,'social media marketing, YouTube channel, buying social media accounts, AccsMarkets, online presence, content creation',0,1,'2026-07-26 21:41:44.905','2026-07-26 21:41:44.915','2026-07-26 21:41:44.915'),('cms2bpqei000gmi17fhsw469r','avoiding-scams-on-social-media-marketplaces-red-flags-and-best-practices-for-buy','Avoiding Scams on Social Media Marketplaces: Red Flags and Best Practices for Buyers and Sellers','Learn how to avoid scams on social media marketplaces with these red flags and best practices for buyers and sellers','<h2>Avoiding Scams on Social Media Marketplaces: An Introduction</h2><p>Social media marketplaces have become increasingly popular in recent years, providing a platform for individuals to buy and sell social media accounts, including Instagram, Twitter, and Facebook accounts. However, with the rise of these marketplaces comes the risk of scams and fraudulent activities. As a buyer or seller, it is essential to be aware of the potential risks and take necessary precautions to avoid falling victim to scams.</p><h2>Red Flags to Watch Out For</h2><p>When buying or selling social media accounts, there are several red flags to watch out for. These include:</p><ul><li>Unrealistic prices: If the price of an account seems too good to be true, it probably is. Be wary of accounts that are significantly underpriced or overpriced.</li><li>Lack of transparency: If the seller is not transparent about the account\'s history, engagement, or followers, it may be a sign of a scam.</li><li>Poor communication: If the seller or buyer is unresponsive or evasive, it can be a sign of a scam.</li><li>Request for personal or financial information: Never provide personal or financial information to a buyer or seller, especially if you are not familiar with them.</li></ul><h3>Best Practices for Buyers</h3><p>As a buyer, there are several best practices to follow when purchasing social media accounts. These include:</p><ul><li>Research the seller: Research the seller\'s reputation and reviews before making a purchase.</li><li>Verify the account\'s ownership: Verify that the seller is the legitimate owner of the account.</li><li>Check the account\'s history: Check the account\'s history, including its posting schedule, engagement, and followers.</li><li>Use a secure payment method: Use a secure payment method, such as PayPal or a credit card, to protect yourself from potential scams.</li></ul><h3>Best Practices for Sellers</h3><p>As a seller, there are several best practices to follow when selling social media accounts. These include:</p><ul><li>Be transparent: Be transparent about the account\'s history, engagement, and followers.</li><li>Provide proof of ownership: Provide proof of ownership, such as screenshots or documentation, to verify that you are the legitimate owner of the account.</li><li>Set a competitive price: Set a competitive price for the account, based on its value and demand.</li><li>Use a secure payment method: Use a secure payment method, such as PayPal or a credit card, to protect yourself from potential scams.</li></ul><h2>Conclusion</h2><p>Avoiding scams on social media marketplaces requires a combination of awareness, research, and caution. By being aware of the potential risks and following best practices, buyers and sellers can protect themselves from scams and ensure a smooth and successful transaction. If you are looking to buy or sell social media accounts, consider using a reputable marketplace like AccsMarkets, which provides a secure and trustworthy platform for buyers and sellers to connect.</p>',NULL,'PUBLISHED',NULL,'social media marketplaces, scams, red flags, best practices, buyers, sellers, AccsMarkets',0,1,'2026-07-26 21:42:04.260','2026-07-26 21:42:04.267','2026-07-26 21:42:04.267'),('cms2bq3pp000lmi17jt22r352','accsmarkets-marketplace-trends-insights-into-the-most-in-demand-social-media-acc','AccsMarkets Marketplace Trends: Insights into the Most In-Demand Social Media Accounts and Niches','Discover the latest trends in social media account demand and niches on AccsMarkets','<h2>Introduction to Social Media Account Trends</h2><p>The social media landscape is constantly evolving, with new platforms and trends emerging every year. As a result, the demand for social media accounts across various niches is also shifting. At AccsMarkets, we have witnessed significant changes in the types of social media accounts that are in high demand. In this article, we will delve into the current trends and insights into the most in-demand social media accounts and niches on our marketplace.</p><h2>Most In-Demand Social Media Platforms</h2><p>Our data shows that the most in-demand social media platforms are Instagram, TikTok, and YouTube. These platforms have seen a significant increase in demand over the past year, with many buyers looking to establish a presence on these platforms. The reasons for this demand are varied, but it is largely due to the vast user base and engagement levels on these platforms.</p><h3>Niche-Specific Demand</h3><p>When it comes to specific niches, we have seen a high demand for social media accounts in the following areas:</p><ul><li>Gaming: With the rise of esports and online gaming, social media accounts focused on gaming content are in high demand.</li><li>Beauty and Fashion: Instagram and TikTok accounts with a focus on beauty and fashion are highly sought after, particularly those with a large and engaged following.</li><li>Health and Wellness: As people become more health-conscious, social media accounts focused on health and wellness are seeing a significant increase in demand.</li><li>Travel: With the rise of travel influencers, social media accounts with a focus on travel and adventure are highly sought after.</li></ul><h2>Factors Affecting Demand</h2><p>There are several factors that affect the demand for social media accounts on our marketplace. These include:</p><ul><li>Engagement levels: Social media accounts with high engagement levels, such as likes, comments, and shares, are in high demand.</li><li>Content quality: Accounts with high-quality content, such as well-produced videos or high-resolution images, are more sought after than those with low-quality content.</li><li>Niche relevance: Social media accounts that are relevant to a specific niche or industry are more in demand than those that are general or miscellaneous.</li><li>Audience demographics: Accounts with a large and engaged following in a specific demographic, such as age or location, are highly sought after.</li></ul><h2>Conclusion</h2><p>In conclusion, the demand for social media accounts on AccsMarkets is constantly evolving, with new trends and niches emerging every year. By understanding the current trends and insights into the most in-demand social media accounts and niches, buyers and sellers can make informed decisions when it comes to buying or selling social media accounts. Whether you are looking to establish a presence on a new platform or expand your existing reach, AccsMarkets is the perfect marketplace to buy or sell social media accounts. Browse our marketplace today and discover the opportunities that await you.</p>',NULL,'PUBLISHED',NULL,'social media accounts, AccsMarkets, marketplace trends, in-demand niches',0,1,'2026-07-26 21:42:21.505','2026-07-26 21:42:21.517','2026-07-26 21:42:21.517');
/*!40000 ALTER TABLE `blogpost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blogtopicqueue`
--

DROP TABLE IF EXISTS `blogtopicqueue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blogtopicqueue` (
  `id` varchar(191) NOT NULL,
  `prompt` text NOT NULL,
  `status` varchar(191) NOT NULL DEFAULT 'PENDING',
  `blogPostId` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `processedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `BlogTopicQueue_status_idx` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blogtopicqueue`
--

LOCK TABLES `blogtopicqueue` WRITE;
/*!40000 ALTER TABLE `blogtopicqueue` DISABLE KEYS */;
INSERT INTO `blogtopicqueue` VALUES ('cmry9lsok000hgkzeup24du58','How to safely buy a YouTube channel on AccsMarkets - Complete Guide 2025','FAILED',NULL,'2026-07-24 01:31:56.660','2026-07-24 01:31:56.991'),('cmry9m09h000jgkze5alf5pp2','How to safely buy a YouTube channel on AccsMarkets - Complete Guide 2025','FAILED',NULL,'2026-07-24 01:32:06.485','2026-07-24 01:32:07.958'),('cmry9m8ti000lgkzebbwp5a0c','How to safely buy a YouTube channel on AccsMarkets - Complete Guide 2025','FAILED',NULL,'2026-07-24 01:32:17.574','2026-07-24 01:32:17.809'),('cmry9opwi0000nb1tk8eq1xct','How to safely buy a YouTube channel on AccsMarkets in 2025','FAILED',NULL,'2026-07-24 01:34:13.023','2026-07-24 01:34:13.808'),('cmry9r99u0002nb1terolxkdv','How to safely buy a YouTube channel on AccsMarkets in 2025','FAILED',NULL,'2026-07-24 01:36:11.442','2026-07-24 01:36:12.345'),('cmry9u1960004nb1tm60i3jbv','How to safely buy a YouTube channel on AccsMarkets in 2025','FAILED',NULL,'2026-07-24 01:38:21.018','2026-07-24 01:38:21.330'),('cmry9x18w0006nb1tyokf4pnz','How to safely buy a YouTube channel on AccsMarkets in 2025','FAILED',NULL,'2026-07-24 01:40:40.977','2026-07-24 01:40:45.084'),('cmry9z7e10008nb1tt5i5yoc7','How to safely buy a YouTube channel on AccsMarkets in 2025','FAILED',NULL,'2026-07-24 01:42:22.249','2026-07-24 01:42:25.899'),('cmrya01u7000anb1twx6jnz5u','How to safely buy a YouTube channel on AccsMarkets in 2025','FAILED',NULL,'2026-07-24 01:43:01.711','2026-07-24 01:43:05.832'),('cmrya19jr000cnb1t83nclj0u','How to safely buy a YouTube channel on AccsMarkets in 2025','DONE','cmrya1ch6000dnb1totgc2y09','2026-07-24 01:43:58.359','2026-07-24 01:44:02.159'),('cmrz9awox0009aa1ok6fcjqo0','How to safely buy a YouTube channel on AccsMarkets in 2026','FAILED',NULL,'2026-07-24 18:11:14.817','2026-07-24 18:11:18.607'),('cmrza2ttt000baa1ooy1rj30a','How to safely buy a YouTube channel on AccsMarkets in 2026','DONE','cmrza2x2e000caa1o3cl4wxzx','2026-07-24 18:32:57.473','2026-07-24 18:33:01.679'),('cmrzcw3k7000013trzs48c9q2','How to safely buy a YouTube channel on AccsMarkets in 2026','FAILED',NULL,'2026-07-24 19:51:42.342','2026-07-24 19:51:42.489'),('cmrzcws34000213trmjpf5kz8','How to safely buy a YouTube channel on AccsMarkets in 2026','FAILED',NULL,'2026-07-24 19:52:14.128','2026-07-24 19:52:14.250'),('cmrzcwsvq000413trhoy00frd','How to safely buy a YouTube channel on AccsMarkets in 2026','FAILED',NULL,'2026-07-24 19:52:15.158','2026-07-24 19:52:15.250'),('cms0ka2iq0000x3aliwaakmqk','A Beginner\'s Guide to Buying Instagram Accounts on AccsMarkets','PENDING',NULL,'2026-07-25 16:06:17.665',NULL),('cms0ka3ur0001x3al5j6i49cv','5 Tips for Sellers to Increase Their Social Media Account\'s Value','PENDING',NULL,'2026-07-25 16:06:19.395',NULL),('cms0ka4h40002x3allce22puk','The Importance of Account Safety: How to Protect Your Social Media Investments','PENDING',NULL,'2026-07-25 16:06:20.200',NULL),('cms0ka58s0003x3alk0vty1u6','The Ultimate Guide to Buying TikTok Accounts: Trends and Pricing Strategies','PENDING',NULL,'2026-07-25 16:06:21.196',NULL),('cms0ka5x70004x3alh29auxj1','How to Avoid Scams When Buying or Selling Social Media Accounts Online','PENDING',NULL,'2026-07-25 16:06:22.075',NULL),('cms0ka6iw0005x3aljj4rd7fp','Valuing Your Facebook Page: A Step-by-Step Guide for Sellers','PENDING',NULL,'2026-07-25 16:06:22.857',NULL),('cms0ka7290006x3al5x5z72qd','The Rise of Niche Discord Servers: How to Buy or Sell a Server on AccsMarkets','PENDING',NULL,'2026-07-25 16:06:23.553',NULL),('cms0ka7mi0007x3al5q0hj57e','Pricing Your Twitter Account for Sale: Factors to Consider and Strategies to Use','PENDING',NULL,'2026-07-25 16:06:24.283',NULL),('cms0ka86t0008x3alx5ov1mmb','Success Story: How One Buyer Turned a Purchased YouTube Channel into a Million-View Sensation','PENDING',NULL,'2026-07-25 16:06:25.014',NULL),('cms0ka8pw0009x3alppmofq5y','The Future of Social Media Marketplaces: Trends to Watch and How to Stay Ahead','PENDING',NULL,'2026-07-25 16:06:25.700',NULL),('cms0kad97000ax3al8ytu41y6','A Beginner\'s Guide to Buying Instagram Accounts on AccsMarkets','FAILED',NULL,'2026-07-25 16:06:31.579','2026-07-25 16:06:35.145'),('cms0knhvr00009hg494hpapnv','A Beginner\'s Guide to Buying Instagram Accounts on AccsMarkets','DONE','cms0knl1r00019hg4uzmgzp0n','2026-07-25 16:16:44.103','2026-07-25 16:16:48.221'),('cms0knque00039hg4y5wb7s63','5 Tips for Sellers to Increase Their Social Media Account\'s Value','FAILED',NULL,'2026-07-25 16:16:55.718','2026-07-25 16:17:00.883'),('cms0knxbu00059hg4f3d2pqgh','5 Tips for Sellers to Increase Their Social Media Account\'s Value','DONE','cms0knzr100069hg41joq1xay','2026-07-25 16:17:04.122','2026-07-25 16:17:07.263'),('cms0ko5xs00089hg4j8zifqzu','The Ultimate Guide to Buying TikTok Accounts: Tips and Tricks','PENDING',NULL,'2026-07-25 16:17:15.281',NULL),('cms0ko6sn00099hg4wh3yjhko','Maximizing Your Earnings: Pricing Strategies for Selling Social Media Accounts','PENDING',NULL,'2026-07-25 16:17:16.391',NULL),('cms0ko7il000a9hg4utp7nlk2','Securing Your Social Media Empire: Account Safety Measures to Implement','PENDING',NULL,'2026-07-25 16:17:17.325',NULL),('cms0ko84w000b9hg418mmr8q1','A Beginner\'s Guide to Buying Facebook Pages on AccsMarkets','PENDING',NULL,'2026-07-25 16:17:18.128',NULL),('cms0ko8oq000c9hg4r24qw8h0','The Rise of Niche Accounts: How to Buy and Sell Specialized Social Media Accounts','PENDING',NULL,'2026-07-25 16:17:18.842',NULL),('cms0ko98t000d9hg4kb8q3kxu','Avoiding Scams on Social Media Marketplaces: Red Flags to Watch Out For','PENDING',NULL,'2026-07-25 16:17:19.565',NULL),('cms0ko9sr000e9hg465twqcwe','Unlocking the Value of Your Account: A Guide to Social Media Account Valuation','PENDING',NULL,'2026-07-25 16:17:20.283',NULL),('cms0koac3000f9hg4dq2uoizc','Discord Server Buying Guide: How to Find and Purchase the Perfect Community','PENDING',NULL,'2026-07-25 16:17:20.980',NULL),('cms0koavu000g9hg4t2veiu6t','Success Stories: How Buying and Selling Social Media Accounts Changed These Entrepreneurs\' Lives','PENDING',NULL,'2026-07-25 16:17:21.690',NULL),('cms0kobho000h9hg4lktedaxe','Twitter Account Buying 101: A Step-by-Step Guide to Finding the Perfect Handle','PENDING',NULL,'2026-07-25 16:17:22.476',NULL),('cms1soe5500044z90zovn46si','The Ultimate Guide to Buying TikTok Accounts: Pricing, Niche, and Engagement Strategies','PENDING',NULL,'2026-07-26 12:49:09.017',NULL),('cms1sofd900054z90ykr489vq','Maximizing Your Earnings: Tips for Selling Facebook Pages with High Engagement Rates','PENDING',NULL,'2026-07-26 12:49:10.605',NULL),('cms1sog4r00064z9034gn55ev','Protecting Your Investment: How to Ensure Account Safety When Buying Social Media Accounts','PENDING',NULL,'2026-07-26 12:49:11.595',NULL),('cms1sogsi00074z90mbgt5xwu','The Rise of Niche Discord Servers: A Guide to Buying and Selling Specialized Communities','PENDING',NULL,'2026-07-26 12:49:12.451',NULL),('cms1soiah00084z90hka2zddb','Pricing Your Social Media Account for Sale: Strategies for Accurate Valuation','PENDING',NULL,'2026-07-26 12:49:14.393',NULL),('cms1soiwy00094z90t1mzck4q','Avoiding Scams on Social Media Marketplaces: Red Flags and Best Practices for Buyers and Sellers','PENDING',NULL,'2026-07-26 12:49:15.203',NULL),('cms1sojl5000a4z90lgwek0yj','Unlocking the Value of Twitter/X Accounts: A Guide to Buying and Selling with High ROI','PENDING',NULL,'2026-07-26 12:49:16.074',NULL),('cms1sokpn000b4z90u2ra94js','Success Stories: How Buying and Selling Social Media Accounts on AccsMarkets Transformed These Users\' Online Presence','PENDING',NULL,'2026-07-26 12:49:17.531',NULL),('cms1solit000c4z90yuclh7qv','AccsMarkets Marketplace Trends: Insights into the Most In-Demand Social Media Accounts and Niches','PENDING',NULL,'2026-07-26 12:49:18.581',NULL),('cms1som4j000d4z90mrczbsyv','The Growing Demand for Gaming Social Media Accounts: Trends, Pricing, and Opportunities','PENDING',NULL,'2026-07-26 12:49:19.364',NULL),('cms1sowfg000e4z908lm3nonf','The Importance of Account Safety: How to Protect Your Social Media Investments','DONE','cms1soxq9000f4z90lmv2muz7','2026-07-26 12:49:32.716','2026-07-26 12:49:34.413'),('cms1sp5hs000h4z90ucjtci83','The Ultimate Guide to Buying TikTok Accounts: Trends and Pricing Strategies','DONE','cms1sp775000i4z900kqyv89k','2026-07-26 12:49:44.464','2026-07-26 12:49:46.680'),('cms1spesy000k4z90rapmymyy','How to Avoid Scams When Buying or Selling Social Media Accounts Online','FAILED',NULL,'2026-07-26 12:49:56.528','2026-07-26 12:49:58.696'),('cms1spi8q000m4z90jldksn3o','How to Avoid Scams When Buying or Selling Social Media Accounts Online','FAILED',NULL,'2026-07-26 12:50:00.986','2026-07-26 12:50:02.941'),('cms1spn3n000o4z900qm4pxad','How to Avoid Scams When Buying or Selling Social Media Accounts Online','FAILED',NULL,'2026-07-26 12:50:07.283','2026-07-26 12:50:09.514'),('cms1t9ij4000025dwwqsbzf3l','How to Avoid Scams When Buying or Selling Social Media Accounts Online','FAILED',NULL,'2026-07-26 13:05:34.481','2026-07-26 13:05:37.102'),('cms1t9vfk000225dw5c483mfj','The Rise of Niche Discord Servers: How to Buy or Sell a Server on AccsMarkets','FAILED',NULL,'2026-07-26 13:05:51.197','2026-07-26 13:05:54.008'),('cms2bp8mw000ami17p6luunl5','Success Story: How One Buyer Turned a Purchased YouTube Channel into a Million-View Sensation','DONE','cms2bpbgy000bmi171chjcwgq','2026-07-26 21:41:41.240','2026-07-26 21:41:44.923'),('cms2bplu6000dmi17ecjsfhhy','Avoiding Scams on Social Media Marketplaces: Red Flags and Best Practices for Buyers and Sellers','FAILED',NULL,'2026-07-26 21:41:58.350','2026-07-26 21:42:00.444'),('cms2bpoxc000fmi170btgyg8u','Avoiding Scams on Social Media Marketplaces: Red Flags and Best Practices for Buyers and Sellers','DONE','cms2bpqei000gmi17fhsw469r','2026-07-26 21:42:02.353','2026-07-26 21:42:04.266'),('cms2bpzrn000imi17r2jrypt1','AccsMarkets Marketplace Trends: Insights into the Most In-Demand Social Media Accounts and Niches','FAILED',NULL,'2026-07-26 21:42:16.403','2026-07-26 21:42:18.635'),('cms2bq23e000kmi17lli974px','AccsMarkets Marketplace Trends: Insights into the Most In-Demand Social Media Accounts and Niches','DONE','cms2bq3pp000lmi17jt22r352','2026-07-26 21:42:19.418','2026-07-26 21:42:21.525');
/*!40000 ALTER TABLE `blogtopicqueue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cannedresponse`
--

DROP TABLE IF EXISTS `cannedresponse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cannedresponse` (
  `id` varchar(191) NOT NULL,
  `title` varchar(191) NOT NULL,
  `body` text NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cannedresponse`
--

LOCK TABLES `cannedresponse` WRITE;
/*!40000 ALTER TABLE `cannedresponse` DISABLE KEYS */;
/*!40000 ALTER TABLE `cannedresponse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contactmessage`
--

DROP TABLE IF EXISTS `contactmessage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contactmessage` (
  `id` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `message` text NOT NULL,
  `ip` varchar(191) DEFAULT NULL,
  `isRead` tinyint(1) NOT NULL DEFAULT 0,
  `readAt` datetime(3) DEFAULT NULL,
  `readById` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `ContactMessage_isRead_createdAt_idx` (`isRead`,`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contactmessage`
--

LOCK TABLES `contactmessage` WRITE;
/*!40000 ALTER TABLE `contactmessage` DISABLE KEYS */;
/*!40000 ALTER TABLE `contactmessage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cookieconsent`
--

DROP TABLE IF EXISTS `cookieconsent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cookieconsent` (
  `id` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `categories` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`categories`)),
  `consentedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `CookieConsent_userId_key` (`userId`),
  CONSTRAINT `CookieConsent_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cookieconsent`
--

LOCK TABLES `cookieconsent` WRITE;
/*!40000 ALTER TABLE `cookieconsent` DISABLE KEYS */;
INSERT INTO `cookieconsent` VALUES ('cmry6tp2v000176vnhoy229d7','cmrxycp3w0007pnrdv1agkll3','{\"essential\":true,\"analytics\":true,\"marketing\":true}','2026-07-24 00:14:06.392','2026-07-24 00:14:06.392'),('cmrz93oot0002aa1o1akm30py','cmrz6qkfk000mvs869uavrwi6','{\"essential\":true,\"analytics\":true,\"marketing\":true}','2026-07-24 18:05:37.853','2026-07-24 18:05:37.853');
/*!40000 ALTER TABLE `cookieconsent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cryptowallet`
--

DROP TABLE IF EXISTS `cryptowallet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cryptowallet` (
  `id` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `network` varchar(191) NOT NULL,
  `address` varchar(191) DEFAULT NULL,
  `paymentId` varchar(191) DEFAULT NULL,
  `status` varchar(191) NOT NULL DEFAULT 'waiting',
  `amountUsd` decimal(12,2) NOT NULL,
  `amountCrypto` decimal(24,8) DEFAULT NULL,
  `currency` varchar(191) NOT NULL,
  `isManual` tinyint(1) NOT NULL DEFAULT 0,
  `txHash` varchar(191) DEFAULT NULL,
  `proofImageUrl` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `confirmedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `CryptoWallet_paymentId_key` (`paymentId`),
  KEY `CryptoWallet_userId_idx` (`userId`),
  KEY `CryptoWallet_status_idx` (`status`),
  CONSTRAINT `CryptoWallet_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cryptowallet`
--

LOCK TABLES `cryptowallet` WRITE;
/*!40000 ALTER TABLE `cryptowallet` DISABLE KEYS */;
/*!40000 ALTER TABLE `cryptowallet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dataerasurerequest`
--

DROP TABLE IF EXISTS `dataerasurerequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dataerasurerequest` (
  `id` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `status` enum('PENDING','READY','EXPIRED','COMPLETED','REVIEWING','DENIED') NOT NULL DEFAULT 'PENDING',
  `requestedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `completedAt` datetime(3) DEFAULT NULL,
  `adminNotes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `DataErasureRequest_userId_idx` (`userId`),
  KEY `DataErasureRequest_status_idx` (`status`),
  CONSTRAINT `DataErasureRequest_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dataerasurerequest`
--

LOCK TABLES `dataerasurerequest` WRITE;
/*!40000 ALTER TABLE `dataerasurerequest` DISABLE KEYS */;
/*!40000 ALTER TABLE `dataerasurerequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dataexportrequest`
--

DROP TABLE IF EXISTS `dataexportrequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dataexportrequest` (
  `id` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `status` enum('PENDING','READY','EXPIRED','COMPLETED','REVIEWING','DENIED') NOT NULL DEFAULT 'PENDING',
  `requestedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `completedAt` datetime(3) DEFAULT NULL,
  `downloadUrl` varchar(191) DEFAULT NULL,
  `expiresAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `DataExportRequest_userId_idx` (`userId`),
  CONSTRAINT `DataExportRequest_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dataexportrequest`
--

LOCK TABLES `dataexportrequest` WRITE;
/*!40000 ALTER TABLE `dataexportrequest` DISABLE KEYS */;
/*!40000 ALTER TABLE `dataexportrequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `depositmethodfee`
--

DROP TABLE IF EXISTS `depositmethodfee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `depositmethodfee` (
  `id` varchar(191) NOT NULL,
  `method` varchar(191) NOT NULL,
  `feeRate` double NOT NULL DEFAULT 0,
  `minFee` double NOT NULL DEFAULT 0,
  `maxFee` double DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT 1,
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DepositMethodFee_method_key` (`method`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `depositmethodfee`
--

LOCK TABLES `depositmethodfee` WRITE;
/*!40000 ALTER TABLE `depositmethodfee` DISABLE KEYS */;
INSERT INTO `depositmethodfee` VALUES ('cmry94ga10000jxse4o87nfcz','crypto',0,0,NULL,1,'2026-07-24 01:18:27.434'),('cmry94ga70001jxselpirxreb','bank_transfer',0.01,2,50,1,'2026-07-24 01:18:27.439'),('cmry94gag0002jxseceiug2sz','card',0.025,1,NULL,1,'2026-07-24 01:18:27.449');
/*!40000 ALTER TABLE `depositmethodfee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devicefingerprint`
--

DROP TABLE IF EXISTS `devicefingerprint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devicefingerprint` (
  `id` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `fingerprintHash` varchar(191) NOT NULL,
  `firstSeenAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `lastSeenAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DeviceFingerprint_userId_fingerprintHash_key` (`userId`,`fingerprintHash`),
  KEY `DeviceFingerprint_fingerprintHash_idx` (`fingerprintHash`),
  KEY `DeviceFingerprint_userId_idx` (`userId`),
  CONSTRAINT `DeviceFingerprint_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devicefingerprint`
--

LOCK TABLES `devicefingerprint` WRITE;
/*!40000 ALTER TABLE `devicefingerprint` DISABLE KEYS */;
/*!40000 ALTER TABLE `devicefingerprint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dispute`
--

DROP TABLE IF EXISTS `dispute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dispute` (
  `id` varchar(191) NOT NULL,
  `escrowId` varchar(191) NOT NULL,
  `openedById` varchar(191) NOT NULL,
  `status` enum('OPEN','UNDER_REVIEW','RESOLVED_BUYER','RESOLVED_SELLER','CLOSED') NOT NULL DEFAULT 'OPEN',
  `reason` text NOT NULL,
  `resolution` text DEFAULT NULL,
  `adminNotes` text DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `resolvedAt` datetime(3) DEFAULT NULL,
  `appealDecision` text DEFAULT NULL,
  `appealReason` text DEFAULT NULL,
  `appealReviewedAt` datetime(3) DEFAULT NULL,
  `appealedAt` datetime(3) DEFAULT NULL,
  `evidenceDeadline` datetime(3) DEFAULT NULL,
  `mediationAccepted` tinyint(1) DEFAULT NULL,
  `mediationCounterOffer` decimal(12,2) DEFAULT NULL,
  `mediationOffer` decimal(12,2) DEFAULT NULL,
  `phase` enum('EVIDENCE','REVIEW','MEDIATION','RULING','APPEAL','FINAL') NOT NULL DEFAULT 'EVIDENCE',
  PRIMARY KEY (`id`),
  UNIQUE KEY `Dispute_escrowId_key` (`escrowId`),
  CONSTRAINT `Dispute_escrowId_fkey` FOREIGN KEY (`escrowId`) REFERENCES `escrow` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dispute`
--

LOCK TABLES `dispute` WRITE;
/*!40000 ALTER TABLE `dispute` DISABLE KEYS */;
/*!40000 ALTER TABLE `dispute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `disputeevidence`
--

DROP TABLE IF EXISTS `disputeevidence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `disputeevidence` (
  `id` varchar(191) NOT NULL,
  `disputeId` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `statement` text NOT NULL,
  `submittedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `attachments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`attachments`)),
  PRIMARY KEY (`id`),
  KEY `DisputeEvidence_disputeId_idx` (`disputeId`),
  KEY `DisputeEvidence_disputeId_userId_idx` (`disputeId`,`userId`),
  CONSTRAINT `DisputeEvidence_disputeId_fkey` FOREIGN KEY (`disputeId`) REFERENCES `dispute` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disputeevidence`
--

LOCK TABLES `disputeevidence` WRITE;
/*!40000 ALTER TABLE `disputeevidence` DISABLE KEYS */;
/*!40000 ALTER TABLE `disputeevidence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `disputetimeline`
--

DROP TABLE IF EXISTS `disputetimeline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `disputetimeline` (
  `id` varchar(191) NOT NULL,
  `disputeId` varchar(191) NOT NULL,
  `eventType` varchar(191) NOT NULL,
  `actorId` varchar(191) DEFAULT NULL,
  `description` text NOT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `DisputeTimeline_disputeId_createdAt_idx` (`disputeId`,`createdAt`),
  CONSTRAINT `DisputeTimeline_disputeId_fkey` FOREIGN KEY (`disputeId`) REFERENCES `dispute` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disputetimeline`
--

LOCK TABLES `disputetimeline` WRITE;
/*!40000 ALTER TABLE `disputetimeline` DISABLE KEYS */;
/*!40000 ALTER TABLE `disputetimeline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emailtemplate`
--

DROP TABLE IF EXISTS `emailtemplate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emailtemplate` (
  `id` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `html` text NOT NULL,
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `EmailTemplate_slug_key` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emailtemplate`
--

LOCK TABLES `emailtemplate` WRITE;
/*!40000 ALTER TABLE `emailtemplate` DISABLE KEYS */;
/*!40000 ALTER TABLE `emailtemplate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `escrow`
--

DROP TABLE IF EXISTS `escrow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `escrow` (
  `id` varchar(191) NOT NULL,
  `listingId` varchar(191) NOT NULL,
  `offerId` varchar(191) DEFAULT NULL,
  `buyerId` varchar(191) NOT NULL,
  `sellerId` varchar(191) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `feeAmount` decimal(12,2) NOT NULL,
  `totalCharged` decimal(12,2) NOT NULL,
  `status` enum('FUNDED','AWAITING_MANAGER_ADD','PENDING_VERIFICATION','SUBMITTED','VERIFIED','IN_TRANSFER','COMPLETED','CANCELLED','DISPUTED') NOT NULL DEFAULT 'FUNDED',
  `cryptoNetwork` varchar(191) DEFAULT NULL,
  `ownershipEmail` varchar(191) DEFAULT NULL,
  `credentialsPayload` text DEFAULT NULL,
  `transferDeadline` datetime(3) DEFAULT NULL,
  `fundedAt` datetime(3) DEFAULT NULL,
  `submittedAt` datetime(3) DEFAULT NULL,
  `verifiedAt` datetime(3) DEFAULT NULL,
  `transferStartedAt` datetime(3) DEFAULT NULL,
  `completedAt` datetime(3) DEFAULT NULL,
  `cancelledAt` datetime(3) DEFAULT NULL,
  `cancelReason` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `isHighValue` tinyint(1) NOT NULL DEFAULT 0,
  `videoVerificationRequired` tinyint(1) NOT NULL DEFAULT 0,
  `videoVerificationCompletedAt` datetime(3) DEFAULT NULL,
  `transferModel` enum('STANDARD','TRUSTLESS') DEFAULT NULL,
  `managerEmailId` varchar(191) DEFAULT NULL,
  `managerAddedAt` datetime(3) DEFAULT NULL,
  `buyerManagerAddedAt` datetime(3) DEFAULT NULL,
  `countdownEndsAt` datetime(3) DEFAULT NULL,
  `escrowOwnerPromotedAt` datetime(3) DEFAULT NULL,
  `sellerConfirmedHandoverAt` datetime(3) DEFAULT NULL,
  `verifiedBy` varchar(191) DEFAULT NULL,
  `organizationId` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Escrow_offerId_key` (`offerId`),
  UNIQUE KEY `Escrow_managerEmailId_key` (`managerEmailId`),
  KEY `Escrow_listingId_idx` (`listingId`),
  KEY `Escrow_buyerId_idx` (`buyerId`),
  KEY `Escrow_sellerId_idx` (`sellerId`),
  KEY `Escrow_status_idx` (`status`),
  KEY `Escrow_organizationId_fkey` (`organizationId`),
  CONSTRAINT `Escrow_buyerId_fkey` FOREIGN KEY (`buyerId`) REFERENCES `user` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `Escrow_listingId_fkey` FOREIGN KEY (`listingId`) REFERENCES `listing` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `Escrow_managerEmailId_fkey` FOREIGN KEY (`managerEmailId`) REFERENCES `escrowmanageremail` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Escrow_offerId_fkey` FOREIGN KEY (`offerId`) REFERENCES `offer` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Escrow_organizationId_fkey` FOREIGN KEY (`organizationId`) REFERENCES `organization` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Escrow_sellerId_fkey` FOREIGN KEY (`sellerId`) REFERENCES `user` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `escrow`
--

LOCK TABLES `escrow` WRITE;
/*!40000 ALTER TABLE `escrow` DISABLE KEYS */;
/*!40000 ALTER TABLE `escrow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `escrowmanageremail`
--

DROP TABLE IF EXISTS `escrowmanageremail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `escrowmanageremail` (
  `id` varchar(191) NOT NULL,
  `address` varchar(191) NOT NULL,
  `platform` varchar(191) NOT NULL,
  `status` enum('AVAILABLE','IN_USE','FLAGGED') NOT NULL DEFAULT 'AVAILABLE',
  `notes` text DEFAULT NULL,
  `addedAsManagerAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `EscrowManagerEmail_address_key` (`address`),
  KEY `EscrowManagerEmail_platform_status_idx` (`platform`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `escrowmanageremail`
--

LOCK TABLES `escrowmanageremail` WRITE;
/*!40000 ALTER TABLE `escrowmanageremail` DISABLE KEYS */;
/*!40000 ALTER TABLE `escrowmanageremail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `escrowmilestone`
--

DROP TABLE IF EXISTS `escrowmilestone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `escrowmilestone` (
  `id` varchar(191) NOT NULL,
  `escrowId` varchar(191) NOT NULL,
  `description` varchar(191) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `status` enum('PENDING','RELEASED') NOT NULL DEFAULT 'PENDING',
  `completedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `EscrowMilestone_escrowId_idx` (`escrowId`),
  CONSTRAINT `EscrowMilestone_escrowId_fkey` FOREIGN KEY (`escrowId`) REFERENCES `escrow` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `escrowmilestone`
--

LOCK TABLES `escrowmilestone` WRITE;
/*!40000 ALTER TABLE `escrowmilestone` DISABLE KEYS */;
/*!40000 ALTER TABLE `escrowmilestone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `featureflag`
--

DROP TABLE IF EXISTS `featureflag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `featureflag` (
  `id` varchar(191) NOT NULL,
  `key` varchar(191) NOT NULL,
  `description` varchar(191) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  `rolloutPct` int(11) NOT NULL DEFAULT 100,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `FeatureFlag_key_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `featureflag`
--

LOCK TABLES `featureflag` WRITE;
/*!40000 ALTER TABLE `featureflag` DISABLE KEYS */;
/*!40000 ALTER TABLE `featureflag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fiatpayment`
--

DROP TABLE IF EXISTS `fiatpayment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fiatpayment` (
  `id` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `provider` varchar(191) NOT NULL,
  `providerPaymentId` varchar(191) NOT NULL,
  `amountUsd` decimal(12,2) NOT NULL,
  `currency` varchar(191) NOT NULL DEFAULT 'usd',
  `status` varchar(191) NOT NULL DEFAULT 'PENDING',
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `completedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `FiatPayment_providerPaymentId_key` (`providerPaymentId`),
  KEY `FiatPayment_userId_idx` (`userId`),
  KEY `FiatPayment_status_idx` (`status`),
  CONSTRAINT `FiatPayment_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fiatpayment`
--

LOCK TABLES `fiatpayment` WRITE;
/*!40000 ALTER TABLE `fiatpayment` DISABLE KEYS */;
/*!40000 ALTER TABLE `fiatpayment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kybsubmission`
--

DROP TABLE IF EXISTS `kybsubmission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kybsubmission` (
  `id` varchar(191) NOT NULL,
  `orgId` varchar(191) NOT NULL,
  `businessName` varchar(191) NOT NULL,
  `registrationNumber` varchar(191) DEFAULT NULL,
  `country` varchar(2) NOT NULL,
  `regDocUrl` varchar(191) DEFAULT NULL,
  `utilityBillUrl` varchar(191) DEFAULT NULL,
  `beneficialOwners` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`beneficialOwners`)),
  `status` varchar(191) NOT NULL DEFAULT 'SUBMITTED',
  `rejectionReason` text DEFAULT NULL,
  `reviewedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `KybSubmission_orgId_key` (`orgId`),
  CONSTRAINT `KybSubmission_orgId_fkey` FOREIGN KEY (`orgId`) REFERENCES `organization` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kybsubmission`
--

LOCK TABLES `kybsubmission` WRITE;
/*!40000 ALTER TABLE `kybsubmission` DISABLE KEYS */;
/*!40000 ALTER TABLE `kybsubmission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kycsubmission`
--

DROP TABLE IF EXISTS `kycsubmission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kycsubmission` (
  `id` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `idFrontUrl` varchar(191) NOT NULL,
  `idBackUrl` varchar(191) NOT NULL,
  `selfieUrl` varchar(191) NOT NULL,
  `ocrName` varchar(191) DEFAULT NULL,
  `ocrDob` varchar(191) DEFAULT NULL,
  `ocrDocNumber` varchar(191) DEFAULT NULL,
  `ocrExpiry` varchar(191) DEFAULT NULL,
  `kycScore` double DEFAULT NULL,
  `isLive` tinyint(1) DEFAULT NULL,
  `faceSimilarity` double DEFAULT NULL,
  `status` varchar(191) NOT NULL DEFAULT 'PENDING',
  `rejectionReason` text DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `reviewedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `KycSubmission_userId_idx` (`userId`),
  KEY `KycSubmission_status_idx` (`status`),
  CONSTRAINT `KycSubmission_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kycsubmission`
--

LOCK TABLES `kycsubmission` WRITE;
/*!40000 ALTER TABLE `kycsubmission` DISABLE KEYS */;
INSERT INTO `kycsubmission` VALUES ('cmrz74p2t0003ha2ax2vhd1dx','cmrz6qkfk000mvs869uavrwi6','https://res.cloudinary.com/ay5pafey/image/upload/s--scPSxCLe--/v1784913006/accsmarkets/kyc/cmrz6qkfk000mvs869uavrwi6/ex7jm2pzy6bxzvbfmg25.jpg','https://res.cloudinary.com/ay5pafey/image/upload/s--1fOz0B45--/v1784913012/accsmarkets/kyc/cmrz6qkfk000mvs869uavrwi6/miw4vnmg6akifgpd9qor.jpg','https://res.cloudinary.com/ay5pafey/image/upload/s--Q42RHmmg--/v1784913022/accsmarkets/kyc/cmrz6qkfk000mvs869uavrwi6/ohiwmodndjxoidge4pxv.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'APPROVED',NULL,'2026-07-24 17:10:25.781','2026-07-24 17:11:11.682');
/*!40000 ALTER TABLE `kycsubmission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `listing`
--

DROP TABLE IF EXISTS `listing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `listing` (
  `id` varchar(191) NOT NULL,
  `sellerId` varchar(191) NOT NULL,
  `platform` enum('YOUTUBE','INSTAGRAM','TIKTOK','FACEBOOK','TELEGRAM','TWITTER_X','SNAPCHAT','PINTEREST','LINKEDIN','WEBSITE') NOT NULL,
  `accountUrl` varchar(191) NOT NULL,
  `title` varchar(191) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `followers` int(11) DEFAULT NULL,
  `engagementRate` double DEFAULT NULL,
  `accountAgeMonths` int(11) DEFAULT NULL,
  `monetized` tinyint(1) NOT NULL DEFAULT 0,
  `lifetimeViews` int(11) DEFAULT NULL,
  `lifetimeRevenue` decimal(12,2) DEFAULT NULL,
  `channelRpm` decimal(8,2) DEFAULT NULL,
  `audienceLanguage` varchar(191) DEFAULT NULL,
  `channelCreationDate` datetime(3) DEFAULT NULL,
  `strikeCount` int(11) NOT NULL DEFAULT 0,
  `warningCount` int(11) NOT NULL DEFAULT 0,
  `strikeWarningContext` text DEFAULT NULL,
  `adsenseStatus` enum('ON','OFF','CHANGEABLE') DEFAULT NULL,
  `displayName` varchar(191) DEFAULT NULL,
  `screenshots` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`screenshots`)),
  `ownershipVerificationCode` varchar(191) DEFAULT NULL,
  `ownershipVerified` tinyint(1) NOT NULL DEFAULT 0,
  `ownershipMethod` varchar(191) DEFAULT NULL,
  `ownershipVerifiedAt` datetime(3) DEFAULT NULL,
  `verifiedPlatformId` varchar(191) DEFAULT NULL,
  `status` enum('DRAFT','PENDING','ACTIVE','SOLD','REJECTED','SUSPENDED','EXPIRED') NOT NULL DEFAULT 'DRAFT',
  `moderationScore` int(11) NOT NULL DEFAULT 0,
  `rejectionReason` varchar(191) DEFAULT NULL,
  `viewCount` int(11) NOT NULL DEFAULT 0,
  `isFeatured` tinyint(1) NOT NULL DEFAULT 0,
  `isPremiumFeatured` tinyint(1) NOT NULL DEFAULT 0,
  `isPinned` tinyint(1) NOT NULL DEFAULT 0,
  `featuredUntil` datetime(3) DEFAULT NULL,
  `pinnedUntil` datetime(3) DEFAULT NULL,
  `lastBumpedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `approvedAt` datetime(3) DEFAULT NULL,
  `soldAt` datetime(3) DEFAULT NULL,
  `saleType` enum('FIXED','AUCTION') NOT NULL DEFAULT 'FIXED',
  `isPrivate` tinyint(1) NOT NULL DEFAULT 0,
  `auctionEndsAt` datetime(3) DEFAULT NULL,
  `reservePrice` decimal(12,2) DEFAULT NULL,
  `buyNowPrice` decimal(12,2) DEFAULT NULL,
  `minBidIncrement` decimal(12,2) DEFAULT NULL,
  `organizationId` varchar(191) DEFAULT NULL,
  `accountLogo` varchar(191) DEFAULT NULL,
  `niche` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Listing_status_platform_idx` (`status`,`platform`),
  KEY `Listing_sellerId_idx` (`sellerId`),
  KEY `Listing_saleType_status_idx` (`saleType`,`status`),
  KEY `Listing_organizationId_fkey` (`organizationId`),
  FULLTEXT KEY `Listing_title_description_idx` (`title`,`description`),
  CONSTRAINT `Listing_organizationId_fkey` FOREIGN KEY (`organizationId`) REFERENCES `organization` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Listing_sellerId_fkey` FOREIGN KEY (`sellerId`) REFERENCES `user` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `listing`
--

LOCK TABLES `listing` WRITE;
/*!40000 ALTER TABLE `listing` DISABLE KEYS */;
INSERT INTO `listing` VALUES ('cmrz8i0i20004dv3lh7s06ldy','cmrz6qkfk000mvs869uavrwi6','YOUTUBE','https://www.youtube.com/channel/UCYK9hj3UADsw36-R4m12UOw','Islamic YouTube Shorts Channel | 1,150 Subscribers | 65% Engagement','Established YouTube Shorts channel focused on Quranic parables and Islamic educational content. The channel currently has 1,150 subscribers, approximately 65% engagement, and is around one month old. It is not monetized yet, giving the buyer an opportunity to continue growing it toward monetization. The channel has an active Islamic-content audience and strong potential for regular short-form uploads. Selling because I am focusing on other projects. Buyers may review the channel analytics before completing the purchase. Full channel ownership and available related assets will be transferred securely after escrow confirmation.',30.00,1150,65,1,0,331000,0.00,0.00,'Arabic','2026-06-13 00:00:00.000',0,0,'NON','OFF','Quran Parables','[\"https://res.cloudinary.com/ay5pafey/image/upload/v1784915302/accsmarkets/listings/r2txpfplsvtwpqwilpqu.png\",\"https://res.cloudinary.com/ay5pafey/image/upload/v1784915311/accsmarkets/listings/hvtlvbvjn5vjlkemgq52.png\",\"https://res.cloudinary.com/ay5pafey/image/upload/v1784915318/accsmarkets/listings/mbztesnp86eqlq1aghy8.png\",\"https://res.cloudinary.com/ay5pafey/image/upload/v1784915324/accsmarkets/listings/qf5p6krggtxfv1jx8q5d.png\"]','AM-4EE4245A',1,'YOUTUBE_API','2026-07-24 17:48:46.726','UCYK9hj3UADsw36-R4m12UOw','ACTIVE',0,NULL,8,0,0,0,NULL,NULL,NULL,'2026-07-24 17:48:46.730','2026-07-25 22:47:27.039','2026-07-24 22:48:07.370',NULL,'FIXED',0,NULL,NULL,NULL,NULL,NULL,'https://lh3.googleusercontent.com/d/1ya3t0Qm8K-CcumZ21pJTU_MA6q7Z6Ghw','Islamic / Religious'),('cms0psn380007o2f2tm7cufq3','cmrz6qkfk000mvs869uavrwi6','YOUTUBE','https://www.youtube.com/channel/UCqyJi8JzUY2aop0fvwgrdhg','Established YouTube Channel Since 2020 – Music, Entertainment & 4K Content','eat Fission is an established YouTube channel with a content history dating back to 2020. The channel includes videos across lo-fi music, entertainment, movie-related content, and 4K travel footage, with one uploaded video reaching over 4,000 views.\n\nThe channel is currently not monetized, and most existing videos are unlisted or private, giving the new owner flexibility to rebrand it and launch a fresh content strategy. It may suit a buyer interested in music, entertainment, travel, compilations, or faceless YouTube content.\n\nThe branded channel name, logo, existing uploads, and channel history are included. Selling because I am focusing on other projects. Transfer will be completed using YouTube’s proper ownership and permissions process.\n\nImportant: Only add claims such as “no strikes,” “copyright clean,” or “eligible for monetization” after confirming them inside YouTube Studio.',50.00,15400,75,580,1,25000000,3.90,1.50,'English','2019-04-14 00:00:00.000',0,0,NULL,'CHANGEABLE','Beat Fusion','[\"https://lh3.googleusercontent.com/d/1noj2rI7vnSf2VyuNHbOg2l8ydDP4YTq2\",\"https://lh3.googleusercontent.com/d/1XU3yflUvOp6YetJAgt5yPVajZ-1sSsV4\",\"https://lh3.googleusercontent.com/d/10DP0EXgb72T_sKuoet7P_2hh6DDmuY7Z\",\"https://lh3.googleusercontent.com/d/1mT8rV2y9LT9C-P5mUpreuBFZ4XIZzQti\"]','AM-379E6C11',1,'YOUTUBE_API','2026-07-25 18:40:42.199','UCqyJi8JzUY2aop0fvwgrdhg','ACTIVE',0,NULL,2,0,0,0,NULL,NULL,NULL,'2026-07-25 18:40:42.212','2026-07-25 23:39:46.142','2026-07-25 18:40:49.833',NULL,'FIXED',0,NULL,NULL,NULL,NULL,NULL,'https://yt3.ggpht.com/I1BsmnGw3nNTPzYj3Vprv2AbggJcFNWPGflD98MIml2nXPT75uZldHY8WY6i_Hgp3IraK3EwhQ=s240-c-k-c0x00ffffff-no-rj','Music');
/*!40000 ALTER TABLE `listing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `listingviewevent`
--

DROP TABLE IF EXISTS `listingviewevent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `listingviewevent` (
  `id` varchar(191) NOT NULL,
  `listingId` varchar(191) NOT NULL,
  `viewerHash` varchar(191) NOT NULL,
  `userId` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `countryCode` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ListingViewEvent_listingId_createdAt_idx` (`listingId`,`createdAt`),
  KEY `ListingViewEvent_listingId_idx` (`listingId`),
  KEY `ListingViewEvent_userId_fkey` (`userId`),
  KEY `ListingViewEvent_countryCode_idx` (`countryCode`),
  CONSTRAINT `ListingViewEvent_listingId_fkey` FOREIGN KEY (`listingId`) REFERENCES `listing` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ListingViewEvent_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `listingviewevent`
--

LOCK TABLES `listingviewevent` WRITE;
/*!40000 ALTER TABLE `listingviewevent` DISABLE KEYS */;
INSERT INTO `listingviewevent` VALUES ('cmrzke0o5000585gbttjoiody','cmrz8i0i20004dv3lh7s06ldy','eff8e7ca506627fe15dda5e0e512fcaad70b6d520f37cc76597fdb4f2d83a1a3',NULL,'2026-07-24 23:21:35.717',NULL),('cmrzlx4pt0001fxlwloak0v0m','cmrz8i0i20004dv3lh7s06ldy','930d2e58b16c6cae9df168ca34e1ad097ef4edce339ca19f59e2ede942612444','cmrzkv4or000685gbijzeqlym','2026-07-25 00:04:27.041',NULL),('cmrzm5ik2000dfxlwvz862992','cmrz8i0i20004dv3lh7s06ldy','930d2e58b16c6cae9df168ca34e1ad097ef4edce339ca19f59e2ede942612444','cmrzkv4or000685gbijzeqlym','2026-07-25 00:10:58.219',NULL),('cmrzma0db0001ymadop179n9x','cmrz8i0i20004dv3lh7s06ldy','930d2e58b16c6cae9df168ca34e1ad097ef4edce339ca19f59e2ede942612444','cmrzkv4or000685gbijzeqlym','2026-07-25 00:14:27.935',NULL),('cmrzmd8ac0001dc4i7b7ghxsf','cmrz8i0i20004dv3lh7s06ldy','930d2e58b16c6cae9df168ca34e1ad097ef4edce339ca19f59e2ede942612444','cmrzkv4or000685gbijzeqlym','2026-07-25 00:16:58.162',NULL),('cmrzt70mu0003xukmypchbs7j','cmrz8i0i20004dv3lh7s06ldy','930d2e58b16c6cae9df168ca34e1ad097ef4edce339ca19f59e2ede942612444','cmrzfl9fa000011acdi1d6g3f','2026-07-25 03:28:05.623',NULL),('cmrzt70nv0005xukmgb0d9msl','cmrz8i0i20004dv3lh7s06ldy','930d2e58b16c6cae9df168ca34e1ad097ef4edce339ca19f59e2ede942612444','cmrzfl9fa000011acdi1d6g3f','2026-07-25 03:28:05.631',NULL),('cms0ylyke0008myn592c4jm29','cmrz8i0i20004dv3lh7s06ldy','784566ac60455a76feb1b4b305686a22fb5d4732fc161e146b99597b4d905734',NULL,'2026-07-25 22:47:27.038',NULL),('cms0yoybh000fmyn538yje4pp','cms0psn380007o2f2tm7cufq3','930d2e58b16c6cae9df168ca34e1ad097ef4edce339ca19f59e2ede942612444',NULL,'2026-07-25 22:49:46.685',NULL),('cms10h8qf0001huv7fdajre39','cms0psn380007o2f2tm7cufq3','930d2e58b16c6cae9df168ca34e1ad097ef4edce339ca19f59e2ede942612444',NULL,'2026-07-25 23:39:46.142',NULL);
/*!40000 ALTER TABLE `listingviewevent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loginattempt`
--

DROP TABLE IF EXISTS `loginattempt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loginattempt` (
  `id` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `ip` varchar(191) NOT NULL,
  `success` tinyint(1) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `LoginAttempt_email_createdAt_idx` (`email`,`createdAt`),
  KEY `LoginAttempt_ip_createdAt_idx` (`ip`,`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loginattempt`
--

LOCK TABLES `loginattempt` WRITE;
/*!40000 ALTER TABLE `loginattempt` DISABLE KEYS */;
INSERT INTO `loginattempt` VALUES ('cmry9edkc000agkzeuho5fwk3','admin@accsmarkets.org','unknown',1,'2026-07-24 01:26:10.476'),('cmrz8wg7g000fu12xa3j4byfl','admin@accsmarket.org','unknown',0,'2026-07-24 18:00:00.268'),('cmrz8wr6p000gu12xk7rv8esr','admin@accsmarkets.org','unknown',0,'2026-07-24 18:00:14.497'),('cmrz8wyff000hu12xgrbjvnic','admin@accsmarkets.org','unknown',0,'2026-07-24 18:00:23.883'),('cmrz8x72t000iu12x2eclpoz7','admin@accsmarkets.org','unknown',0,'2026-07-24 18:00:35.094'),('cmrz8xkjb000ju12xv9bq3awk','admin@accsmarkets.org','unknown',0,'2026-07-24 18:00:52.536'),('cmrz8yt2v0000aa1o1402bj5m','admin@accsmarkets.org','unknown',0,'2026-07-24 18:01:50.263'),('cmrz96r6j0003aa1o10yraqbk','support@accsmarkets.org','unknown',1,'2026-07-24 18:08:01.051'),('cmrzaz31b000eaa1o3pd92s23','admin@accsmarket.org','unknown',0,'2026-07-24 18:58:02.400'),('cmrzb0ng1000faa1okvyf4bq3','support@accsmarkets.org','unknown',1,'2026-07-24 18:59:15.506'),('cmrzthjus000bxukmuezrm05o','support@accsmarkets.org','unknown',1,'2026-07-25 03:36:17.092'),('cms0eof6s000cxukmuzbz4a7o','support@accsmarkets.org','unknown',1,'2026-07-25 13:29:29.572'),('cms1yn2o3000525dwdliw8lm3','support@accsmarkets.org','unknown',1,'2026-07-26 15:36:05.188');
/*!40000 ALTER TABLE `loginattempt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `message` (
  `id` varchar(191) NOT NULL,
  `conversationId` varchar(191) NOT NULL,
  `senderId` varchar(191) NOT NULL,
  `recipientId` varchar(191) NOT NULL,
  `escrowId` varchar(191) DEFAULT NULL,
  `content` text NOT NULL,
  `attachmentUrl` varchar(191) DEFAULT NULL,
  `attachmentName` varchar(191) DEFAULT NULL,
  `isRead` tinyint(1) NOT NULL DEFAULT 0,
  `isArchived` tinyint(1) NOT NULL DEFAULT 0,
  `moderationFlagged` tinyint(1) NOT NULL DEFAULT 0,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `isPinned` tinyint(1) NOT NULL DEFAULT 0,
  `pinnedAt` datetime(3) DEFAULT NULL,
  `pinnedById` varchar(191) DEFAULT NULL,
  `listingId` varchar(191) DEFAULT NULL,
  `chatOfferId` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Message_conversationId_createdAt_idx` (`conversationId`,`createdAt`),
  KEY `Message_recipientId_isRead_idx` (`recipientId`,`isRead`),
  KEY `Message_senderId_fkey` (`senderId`),
  KEY `Message_escrowId_isPinned_idx` (`escrowId`,`isPinned`),
  KEY `Message_listingId_fkey` (`listingId`),
  KEY `Message_chatOfferId_idx` (`chatOfferId`),
  CONSTRAINT `Message_chatOfferId_fkey` FOREIGN KEY (`chatOfferId`) REFERENCES `offer` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Message_escrowId_fkey` FOREIGN KEY (`escrowId`) REFERENCES `escrow` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Message_listingId_fkey` FOREIGN KEY (`listingId`) REFERENCES `listing` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Message_senderId_fkey` FOREIGN KEY (`senderId`) REFERENCES `user` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message`
--

LOCK TABLES `message` WRITE;
/*!40000 ALTER TABLE `message` DISABLE KEYS */;
INSERT INTO `message` VALUES ('cmrzb6kac000iaa1orw7eag4o','cmrxycp3w0007pnrdv1agkll3_cmrz6qkfk000mvs869uavrwi6','cmrz6qkfk000mvs869uavrwi6','cmrxycp3w0007pnrdv1agkll3',NULL,'hi',NULL,NULL,1,0,0,'2026-07-24 19:03:51.348',0,NULL,NULL,NULL,NULL),('cmrzb6zmd000naa1och2wx06f','cmrxycp3w0007pnrdv1agkll3_cmrz6qkfk000mvs869uavrwi6','cmrxycp3w0007pnrdv1agkll3','cmrz6qkfk000mvs869uavrwi6',NULL,'hello how may i help you',NULL,NULL,1,0,0,'2026-07-24 19:04:11.222',0,NULL,NULL,NULL,NULL),('cmrzlxa1k0004fxlwhli747pw','cmrz6qkfk000mvs869uavrwi6_cmrzkv4or000685gbijzeqlym','cmrzkv4or000685gbijzeqlym','cmrz6qkfk000mvs869uavrwi6',NULL,'hi',NULL,NULL,1,0,0,'2026-07-25 00:04:33.944',0,NULL,NULL,NULL,NULL),('cmrzlxok40009fxlwoj9t48vi','cmrz6qkfk000mvs869uavrwi6_cmrzkv4or000685gbijzeqlym','cmrz6qkfk000mvs869uavrwi6','cmrzkv4or000685gbijzeqlym',NULL,'hello',NULL,NULL,1,0,0,'2026-07-25 00:04:52.756',0,NULL,NULL,NULL,NULL),('cmrzm5lbf000gfxlws5erdm7a','cmrz6qkfk000mvs869uavrwi6_cmrzkv4or000685gbijzeqlym','cmrzkv4or000685gbijzeqlym','cmrz6qkfk000mvs869uavrwi6',NULL,'https://accsmarkets.org/listings/cmrz8i0i20004dv3lh7s06ldy',NULL,NULL,1,0,1,'2026-07-25 00:11:01.804',0,NULL,NULL,NULL,NULL),('cmrzmegp60004dc4ivq9zzmp1','cmrz6qkfk000mvs869uavrwi6_cmrzkv4or000685gbijzeqlym','cmrzkv4or000685gbijzeqlym','cmrz6qkfk000mvs869uavrwi6',NULL,'😂',NULL,NULL,1,0,0,'2026-07-25 00:17:55.722',0,NULL,NULL,NULL,NULL),('cms0xk3yt0006myn5smxz213g','cmrxycp3w0007pnrdv1agkll3_cms0xju3j0002myn5c030pq5v','cmrxycp3w0007pnrdv1agkll3','cms0xju3j0002myn5c030pq5v',NULL,'Welcome to AccsMarkets! I\'m your dedicated support agent. Feel free to ask me anything about escrow, buying, selling, or your account. I typically respond within a few hours.',NULL,NULL,0,0,0,'2026-07-25 22:18:01.109',0,NULL,NULL,NULL,NULL),('cms13gpcp0003rfmvcr65bx2e','cmrz6qkfk000mvs869uavrwi6_cmrzkv4or000685gbijzeqlym','cmrz6qkfk000mvs869uavrwi6','cmrzkv4or000685gbijzeqlym',NULL,'{\"_type\":\"chat_offer\",\"offerId\":\"cms13gpbw0001rfmv5pjcnbpe\",\"listingId\":\"cmrz8i0i20004dv3lh7s06ldy\",\"listingTitle\":\"Islamic YouTube Shorts Channel | 1,150 Subscribers | 65% Engagement\",\"price\":30,\"note\":null,\"expiresAt\":\"2026-07-28T01:03:19.865Z\"}',NULL,NULL,0,0,0,'2026-07-26 01:03:19.897',0,NULL,NULL,NULL,'cms13gpbw0001rfmv5pjcnbpe');
/*!40000 ALTER TABLE `message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification` (
  `id` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `type` enum('LISTING','LISTING_APPROVED','LISTING_REJECTED','OFFER','ESCROW','MESSAGE','PAYMENT','DEPOSIT_CONFIRMED','SYSTEM','DISPUTE','SECURITY') NOT NULL,
  `title` varchar(191) NOT NULL,
  `body` text NOT NULL,
  `link` varchar(191) DEFAULT NULL,
  `isRead` tinyint(1) NOT NULL DEFAULT 0,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `Notification_userId_isRead_idx` (`userId`,`isRead`),
  CONSTRAINT `Notification_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
INSERT INTO `notification` VALUES ('cmrz75oiz0005ha2apqq67ogx','cmrz6qkfk000mvs869uavrwi6','SYSTEM','ID verification approved','Your identity has been verified. Your account is now fully verified.','/dashboard/settings',1,'2026-07-24 17:11:11.723'),('cmrz96xll0008aa1opjtxb706','cmrz6qkfk000mvs869uavrwi6','LISTING_APPROVED','Listing approved 🎉','\"Islamic YouTube Shorts Channel | 1,150 Subscribers | 65% Engagement\" is now live on the marketplace.','/listings/cmrz8i0i20004dv3lh7s06ldy',1,'2026-07-24 18:08:09.369'),('cmrzb6kan000kaa1o221u8p7q','cmrxycp3w0007pnrdv1agkll3','MESSAGE','New message from maliknain','hi','/dashboard/messages/cmrz6qkfk000mvs869uavrwi6',0,'2026-07-24 19:03:51.359'),('cmrzb6zmk000paa1owsnlgaps','cmrz6qkfk000mvs869uavrwi6','MESSAGE','New message from support','hello how may i help you','/dashboard/messages/cmrxycp3w0007pnrdv1agkll3',1,'2026-07-24 19:04:11.228'),('cmrzj6z1t0004vaxn4zqzhmqe','cmrz6qkfk000mvs869uavrwi6','LISTING_APPROVED','Listing approved 🎉','\"Islamic YouTube Shorts Channel | 1,150 Subscribers | 65% Engagement\" is now live on the marketplace.','/listings/cmrz8i0i20004dv3lh7s06ldy',1,'2026-07-24 22:48:07.410'),('cmrzlxa1u0006fxlwg4qhp52t','cmrz6qkfk000mvs869uavrwi6','MESSAGE','New message from Cheryl Coffey','hi','/dashboard/messages/cmrzkv4or000685gbijzeqlym',1,'2026-07-25 00:04:33.955'),('cmrzlxoka000bfxlwb8l2rmdz','cmrzkv4or000685gbijzeqlym','MESSAGE','New message from maliknain','hello','/dashboard/messages/cmrz6qkfk000mvs869uavrwi6',0,'2026-07-25 00:04:52.762'),('cmrzm5lbq000ifxlw7b07i6rj','cmrz6qkfk000mvs869uavrwi6','MESSAGE','New message from Cheryl Coffey','https://accsmarkets.org/listings/cmrz8i0i20004dv3lh7s06ldy','/dashboard/messages/cmrzkv4or000685gbijzeqlym',1,'2026-07-25 00:11:01.815'),('cmrzmegpf0006dc4ia8h7uq3h','cmrz6qkfk000mvs869uavrwi6','MESSAGE','New message from Cheryl Coffey','😂','/dashboard/messages/cmrzkv4or000685gbijzeqlym',1,'2026-07-25 00:17:55.731'),('cmrztbuyc000axukmxaxpc188','cmrz6qkfk000mvs869uavrwi6','OFFER','New offer received','$20.00 offer on \"Islamic YouTube Shorts Channel | 1,150 Subscribers | 65% Engagement\"','/dashboard/offers',1,'2026-07-25 03:31:51.540'),('cms0j0v0c000168epkyzze4yb','cmrzfl9fa000011acdi1d6g3f','OFFER','Offer declined','Your offer on \"Islamic YouTube Shorts Channel | 1,150 Subscribers | 65% Engagement\" was declined.','/dashboard/offers',0,'2026-07-25 15:31:08.412'),('cms0psszo000eo2f23z6r1q56','cmrz6qkfk000mvs869uavrwi6','LISTING_APPROVED','Listing approved 🎉','\"Established YouTube Channel Since 2020 – Music, Entertainment & 4K Content\" is now live on the marketplace.','/listings/cms0psn380007o2f2tm7cufq3',1,'2026-07-25 18:40:49.860'),('cms13gpdq0005rfmvkdmeid2e','cmrzkv4or000685gbijzeqlym','OFFER','New price offer for \"Islamic YouTube Shorts Channel | 1,150 Subscribers | 65% Engagement\"','$30.00 — No note','/dashboard/messages/cmrz6qkfk000mvs869uavrwi6',0,'2026-07-26 01:03:19.934'),('cms13h6k00007rfmvycagva91','cmrzkv4or000685gbijzeqlym','OFFER','Offer declined','Your offer on \"Islamic YouTube Shorts Channel | 1,150 Subscribers | 65% Engagement\" was declined.','/dashboard/offers',0,'2026-07-26 01:03:42.193'),('cms2bcjrv0009mi177qrh842t','cmrz6qkfk000mvs869uavrwi6','PAYMENT','Bank transfer rejected','Your bank transfer could not be verified. Contact support if this is a mistake.','/dashboard/wallet/deposit/bank-transfer/cms2bbf170004mi17l1wl6v99',0,'2026-07-26 21:31:49.147');
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `npsresponse`
--

DROP TABLE IF EXISTS `npsresponse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `npsresponse` (
  `id` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `score` int(11) NOT NULL,
  `comment` text DEFAULT NULL,
  `submittedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `NpsResponse_userId_idx` (`userId`),
  CONSTRAINT `NpsResponse_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `npsresponse`
--

LOCK TABLES `npsresponse` WRITE;
/*!40000 ALTER TABLE `npsresponse` DISABLE KEYS */;
/*!40000 ALTER TABLE `npsresponse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offer`
--

DROP TABLE IF EXISTS `offer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offer` (
  `id` varchar(191) NOT NULL,
  `listingId` varchar(191) NOT NULL,
  `buyerId` varchar(191) NOT NULL,
  `sellerId` varchar(191) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `message` text DEFAULT NULL,
  `status` enum('PENDING','ACCEPTED','DECLINED','EXPIRED','COUNTERED','CANCELLED') NOT NULL DEFAULT 'PENDING',
  `parentOfferId` varchar(191) DEFAULT NULL,
  `round` int(11) NOT NULL DEFAULT 1,
  `expiresAt` datetime(3) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Offer_listingId_buyerId_status_idx` (`listingId`,`buyerId`,`status`),
  KEY `Offer_sellerId_status_idx` (`sellerId`,`status`),
  KEY `Offer_buyerId_fkey` (`buyerId`),
  KEY `Offer_parentOfferId_fkey` (`parentOfferId`),
  CONSTRAINT `Offer_buyerId_fkey` FOREIGN KEY (`buyerId`) REFERENCES `user` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `Offer_listingId_fkey` FOREIGN KEY (`listingId`) REFERENCES `listing` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `Offer_parentOfferId_fkey` FOREIGN KEY (`parentOfferId`) REFERENCES `offer` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offer`
--

LOCK TABLES `offer` WRITE;
/*!40000 ALTER TABLE `offer` DISABLE KEYS */;
INSERT INTO `offer` VALUES ('cmrztbuy10008xukmm5aqqkdx','cmrz8i0i20004dv3lh7s06ldy','cmrzfl9fa000011acdi1d6g3f','cmrz6qkfk000mvs869uavrwi6',20.00,NULL,'DECLINED',NULL,1,'2026-07-28 03:31:51.525','2026-07-25 03:31:51.529','2026-07-25 15:31:08.404'),('cms13gpbw0001rfmv5pjcnbpe','cmrz8i0i20004dv3lh7s06ldy','cmrzkv4or000685gbijzeqlym','cmrz6qkfk000mvs869uavrwi6',30.00,NULL,'DECLINED',NULL,1,'2026-07-28 01:03:19.865','2026-07-26 01:03:19.866','2026-07-26 01:03:42.176');
/*!40000 ALTER TABLE `offer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization`
--

DROP TABLE IF EXISTS `organization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organization` (
  `id` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `ownerId` varchar(191) NOT NULL,
  `kybStatus` enum('NONE','SUBMITTED','APPROVED','REJECTED') NOT NULL DEFAULT 'NONE',
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Organization_ownerId_idx` (`ownerId`),
  CONSTRAINT `Organization_ownerId_fkey` FOREIGN KEY (`ownerId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization`
--

LOCK TABLES `organization` WRITE;
/*!40000 ALTER TABLE `organization` DISABLE KEYS */;
/*!40000 ALTER TABLE `organization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organizationmember`
--

DROP TABLE IF EXISTS `organizationmember`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organizationmember` (
  `id` varchar(191) NOT NULL,
  `orgId` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `role` enum('OWNER','ADMIN','MEMBER') NOT NULL DEFAULT 'MEMBER',
  `invitedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `joinedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `OrganizationMember_orgId_userId_key` (`orgId`,`userId`),
  KEY `OrganizationMember_userId_idx` (`userId`),
  CONSTRAINT `OrganizationMember_orgId_fkey` FOREIGN KEY (`orgId`) REFERENCES `organization` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `OrganizationMember_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organizationmember`
--

LOCK TABLES `organizationmember` WRITE;
/*!40000 ALTER TABLE `organizationmember` DISABLE KEYS */;
/*!40000 ALTER TABLE `organizationmember` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phoneverification`
--

DROP TABLE IF EXISTS `phoneverification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phoneverification` (
  `id` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `phoneNumber` varchar(191) NOT NULL,
  `codeHash` varchar(191) NOT NULL,
  `expiresAt` datetime(3) NOT NULL,
  `verifiedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `PhoneVerification_userId_key` (`userId`),
  CONSTRAINT `PhoneVerification_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phoneverification`
--

LOCK TABLES `phoneverification` WRITE;
/*!40000 ALTER TABLE `phoneverification` DISABLE KEYS */;
INSERT INTO `phoneverification` VALUES ('cmrz73q9x0001ha2ah67ma49v','cmrz6qkfk000mvs869uavrwi6','americanhistory921@gmail.com','3315564ae2be13e1b0773a9238e40247075bd1d04308d8d08cb285a0465925b6','2026-07-26 00:26:08.266',NULL,'2026-07-24 17:09:40.678');
/*!40000 ALTER TABLE `phoneverification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `platformbankaccount`
--

DROP TABLE IF EXISTS `platformbankaccount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `platformbankaccount` (
  `id` varchar(191) NOT NULL,
  `bankName` varchar(191) NOT NULL,
  `accountName` varchar(191) NOT NULL,
  `accountNumber` varchar(191) NOT NULL,
  `routingNumber` varchar(191) DEFAULT NULL,
  `swiftCode` varchar(191) DEFAULT NULL,
  `iban` varchar(191) DEFAULT NULL,
  `currency` varchar(191) NOT NULL DEFAULT 'USD',
  `isActive` tinyint(1) NOT NULL DEFAULT 1,
  `sortOrder` int(11) NOT NULL DEFAULT 0,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `PlatformBankAccount_isActive_sortOrder_idx` (`isActive`,`sortOrder`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `platformbankaccount`
--

LOCK TABLES `platformbankaccount` WRITE;
/*!40000 ALTER TABLE `platformbankaccount` DISABLE KEYS */;
INSERT INTO `platformbankaccount` VALUES ('cms1ymvyl000425dwgtimp17c','Meezan Bank','ZULQARNAIN PERVAIZ','03350106933056',NULL,'MEZNPKKAXXX','PK13MEZN0003350106933056','USD',1,1,'2026-07-26 15:35:56.490','2026-07-26 21:31:58.134'),('cms1yp1uc000625dwas1vzbhj','Lead Bank in the USA','ZULQARNAIN PERVAIZ','219191127779','101019644',NULL,NULL,'USD',1,1,'2026-07-26 15:37:37.428','2026-07-26 15:37:37.428');
/*!40000 ALTER TABLE `platformbankaccount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `platformsettings`
--

DROP TABLE IF EXISTS `platformsettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `platformsettings` (
  `id` varchar(191) NOT NULL DEFAULT 'singleton',
  `siteName` varchar(191) NOT NULL DEFAULT 'AccsMarkets',
  `maintenanceMode` tinyint(1) NOT NULL DEFAULT 0,
  `registrationOpen` tinyint(1) NOT NULL DEFAULT 1,
  `requireEmailVerification` tinyint(1) NOT NULL DEFAULT 1,
  `minDeposit` decimal(12,2) NOT NULL DEFAULT 10.00,
  `minWithdrawal` decimal(12,2) NOT NULL DEFAULT 20.00,
  `escrowTransferDays` int(11) NOT NULL DEFAULT 3,
  `disputeWindowHours` int(11) NOT NULL DEFAULT 48,
  `highValueEscrowThreshold` decimal(12,2) NOT NULL DEFAULT 500.00,
  `officialSupportUserId` varchar(191) DEFAULT NULL,
  `listingReviewHours` int(11) NOT NULL DEFAULT 48,
  `bankTransferShortfallToleranceUsd` double NOT NULL DEFAULT 1,
  `bankTransferShortfallTolerancePct` double NOT NULL DEFAULT 0.01,
  `updatedAt` datetime(3) NOT NULL,
  `maintenanceAllowAdmins` tinyint(1) NOT NULL DEFAULT 1,
  `maintenanceEndTime` datetime(3) DEFAULT NULL,
  `maintenanceMessage` text DEFAULT NULL,
  `maintenanceTitle` varchar(191) DEFAULT NULL,
  `walletAddressBep20` varchar(191) DEFAULT NULL,
  `walletAddressErc20` varchar(191) DEFAULT NULL,
  `walletAddressMatic` varchar(191) DEFAULT NULL,
  `walletAddressSol` varchar(191) DEFAULT NULL,
  `walletAddressTrc20` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `platformsettings`
--

LOCK TABLES `platformsettings` WRITE;
/*!40000 ALTER TABLE `platformsettings` DISABLE KEYS */;
INSERT INTO `platformsettings` VALUES ('singleton','AccsMarkets',0,1,1,10.00,20.00,7,48,500.00,'cmrxycp3w0007pnrdv1agkll3',48,10,0.01,'2026-07-24 21:32:16.451',1,NULL,'We\'ll be back shortly. Thank you for your patience.','Maintenance in Progress','0x9ecf9a8910fced331af9f4aded9fc3e36b9e849d','0x9ecf9a8910fced331af9f4aded9fc3e36b9e849d','0x9ecf9a8910fced331af9f4aded9fc3e36b9e849d','2WVSGdVcRQcF9HzsCk1FvJbY8CFdPQ2MGcjFeK3RbbEv','TES5qQBonXRjB6ZLt1An8AvizWybGx3pRN');
/*!40000 ALTER TABLE `platformsettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `platformtransferpolicy`
--

DROP TABLE IF EXISTS `platformtransferpolicy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `platformtransferpolicy` (
  `id` varchar(191) NOT NULL,
  `platform` varchar(191) NOT NULL,
  `transferDays` int(11) NOT NULL DEFAULT 3,
  `policyNote` text DEFAULT NULL,
  `allowTrustless` tinyint(1) NOT NULL DEFAULT 0,
  `trustlessBootstrapDays` int(11) NOT NULL DEFAULT 7,
  `sourceNote` text DEFAULT NULL,
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `PlatformTransferPolicy_platform_key` (`platform`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `platformtransferpolicy`
--

LOCK TABLES `platformtransferpolicy` WRITE;
/*!40000 ALTER TABLE `platformtransferpolicy` DISABLE KEYS */;
INSERT INTO `platformtransferpolicy` VALUES ('cmrxycpcl0043pnrd5d1z255z','YOUTUBE',7,'YouTube channels transfer via manager email invite. Buyer must have a Google account.',1,7,'YouTube Creator Studio ownership transfer','2026-07-23 23:58:20.109'),('cmrxycpcq0044pnrdrwi0habe','INSTAGRAM',7,'Instagram accounts transfer via email/phone change. Requires 2FA disable first.',1,7,'Instagram Help Center','2026-07-23 23:58:27.178'),('cmrxycpcu0045pnrdx9rqfklz','TIKTOK',2,'TikTok accounts transfer via email change. Phone number must be removed first.',1,2,'TikTok Support','2026-07-23 23:58:58.026'),('cmrxycpd30046pnrdcbvus6fo','TWITTER_X',2,'X accounts transfer via email/phone change. Premium subscription does NOT transfer.',0,5,'X Help Center','2026-07-23 20:16:56.679'),('cmrxycpd70047pnrd4xg4t5b4','TELEGRAM',1,'Telegram channels transfer via admin rights. Groups transfer via owner change.',0,3,'Telegram FAQ','2026-07-23 23:59:02.042'),('cmrxycpdb0048pnrdbx685x7s','FACEBOOK',7,'Facebook pages transfer via admin role assignment. Personal profiles cannot be transferred.',1,7,'Facebook Business Help','2026-07-23 23:58:57.303');
/*!40000 ALTER TABLE `platformtransferpolicy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `privatelistinginvite`
--

DROP TABLE IF EXISTS `privatelistinginvite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `privatelistinginvite` (
  `id` varchar(191) NOT NULL,
  `listingId` varchar(191) NOT NULL,
  `invitedUserId` varchar(191) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `PrivateListingInvite_listingId_invitedUserId_key` (`listingId`,`invitedUserId`),
  KEY `PrivateListingInvite_invitedUserId_idx` (`invitedUserId`),
  CONSTRAINT `PrivateListingInvite_invitedUserId_fkey` FOREIGN KEY (`invitedUserId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `PrivateListingInvite_listingId_fkey` FOREIGN KEY (`listingId`) REFERENCES `listing` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `privatelistinginvite`
--

LOCK TABLES `privatelistinginvite` WRITE;
/*!40000 ALTER TABLE `privatelistinginvite` DISABLE KEYS */;
/*!40000 ALTER TABLE `privatelistinginvite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promocode`
--

DROP TABLE IF EXISTS `promocode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `promocode` (
  `id` varchar(191) NOT NULL,
  `code` varchar(191) NOT NULL,
  `type` enum('PERCENT_OFF_FEE','FLAT_CREDIT') NOT NULL,
  `value` decimal(12,2) NOT NULL,
  `maxRedemptions` int(11) DEFAULT NULL,
  `redemptionCount` int(11) NOT NULL DEFAULT 0,
  `expiresAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `PromoCode_code_key` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promocode`
--

LOCK TABLES `promocode` WRITE;
/*!40000 ALTER TABLE `promocode` DISABLE KEYS */;
/*!40000 ALTER TABLE `promocode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promoredemption`
--

DROP TABLE IF EXISTS `promoredemption`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `promoredemption` (
  `id` varchar(191) NOT NULL,
  `promoCodeId` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `redeemedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `PromoRedemption_promoCodeId_userId_key` (`promoCodeId`,`userId`),
  KEY `PromoRedemption_userId_idx` (`userId`),
  CONSTRAINT `PromoRedemption_promoCodeId_fkey` FOREIGN KEY (`promoCodeId`) REFERENCES `promocode` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `PromoRedemption_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promoredemption`
--

LOCK TABLES `promoredemption` WRITE;
/*!40000 ALTER TABLE `promoredemption` DISABLE KEYS */;
/*!40000 ALTER TABLE `promoredemption` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pushsubscription`
--

DROP TABLE IF EXISTS `pushsubscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pushsubscription` (
  `id` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `endpoint` varchar(1000) NOT NULL,
  `p256dh` varchar(500) NOT NULL,
  `auth` varchar(200) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `PushSubscription_endpoint_key` (`endpoint`) USING HASH,
  KEY `PushSubscription_userId_idx` (`userId`),
  CONSTRAINT `PushSubscription_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pushsubscription`
--

LOCK TABLES `pushsubscription` WRITE;
/*!40000 ALTER TABLE `pushsubscription` DISABLE KEYS */;
/*!40000 ALTER TABLE `pushsubscription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ratelimitevent`
--

DROP TABLE IF EXISTS `ratelimitevent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ratelimitevent` (
  `id` varchar(191) NOT NULL,
  `key` varchar(191) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `RateLimitEvent_key_createdAt_idx` (`key`,`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ratelimitevent`
--

LOCK TABLES `ratelimitevent` WRITE;
/*!40000 ALTER TABLE `ratelimitevent` DISABLE KEYS */;
INSERT INTO `ratelimitevent` VALUES ('cms2bbf0w0002mi17fzkvqwr6','bank-deposit:cmrz6qkfk000mvs869uavrwi6','2026-07-26 21:30:56.336'),('cmry5llwo000aj7hughojvjga','forgot-password:::1','2026-07-23 23:39:49.416'),('cms0psn2g0005o2f2qawo2sc3','listing-create:cmrz6qkfk000mvs869uavrwi6','2026-07-25 18:40:42.184'),('cmrzb6zm3000laa1ooiivf3y3','messages:cmrxycp3w0007pnrdv1agkll3','2026-07-24 19:04:11.212'),('cmrzlxojk0007fxlw5rlf9bhc','messages:cmrz6qkfk000mvs869uavrwi6','2026-07-25 00:04:52.736'),('cmrzmegoo0002dc4iyohzsfrn','messages:cmrzkv4or000685gbijzeqlym','2026-07-25 00:17:55.704'),('cmrztbuxd0006xukmws4my4v1','offers:cmrzfl9fa000011acdi1d6g3f','2026-07-25 03:31:51.505'),('cmry6uwvw000276vn1y4cm4eq','register:::1','2026-07-24 00:15:03.165'),('cmry6v1bi000376vn7m2gaeth','register:::1','2026-07-24 00:15:08.911'),('cmry6v21n000476vnry2t43a6','register:::1','2026-07-24 00:15:09.852'),('cms0xjtoz0000myn5t0ql8vuz','register:92.96.11.80','2026-07-25 22:17:47.794'),('cms0ymlt90009myn52vgybgds','register:92.96.11.80','2026-07-25 22:47:57.166'),('cms0plljn0004o2f2b1xore3i','yt-check:cmrz6qkfk000mvs869uavrwi6','2026-07-25 18:35:13.619');
/*!40000 ALTER TABLE `ratelimitevent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `referral`
--

DROP TABLE IF EXISTS `referral`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `referral` (
  `id` varchar(191) NOT NULL,
  `referrerId` varchar(191) NOT NULL,
  `refereeId` varchar(191) NOT NULL,
  `referralCodeId` varchar(191) NOT NULL,
  `status` enum('PENDING','REWARDED') NOT NULL DEFAULT 'PENDING',
  `rewardedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `Referral_refereeId_key` (`refereeId`),
  KEY `Referral_referrerId_idx` (`referrerId`),
  KEY `Referral_referralCodeId_idx` (`referralCodeId`),
  CONSTRAINT `Referral_refereeId_fkey` FOREIGN KEY (`refereeId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Referral_referralCodeId_fkey` FOREIGN KEY (`referralCodeId`) REFERENCES `referralcode` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referral`
--

LOCK TABLES `referral` WRITE;
/*!40000 ALTER TABLE `referral` DISABLE KEYS */;
/*!40000 ALTER TABLE `referral` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `referralcode`
--

DROP TABLE IF EXISTS `referralcode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `referralcode` (
  `id` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `code` varchar(191) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ReferralCode_userId_key` (`userId`),
  UNIQUE KEY `ReferralCode_code_key` (`code`),
  CONSTRAINT `ReferralCode_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referralcode`
--

LOCK TABLES `referralcode` WRITE;
/*!40000 ALTER TABLE `referralcode` DISABLE KEYS */;
INSERT INTO `referralcode` VALUES ('cmry1p3xm0001w7bzazjs01ep','cmrxycp4k000fpnrdtvjgadqb','JASONPSHF4XT','2026-07-23 21:50:34.283'),('cmrzbf01z000raa1o192fhxtl','cmrz6qkfk000mvs869uavrwi6','MALIKNFOQDYT','2026-07-24 19:10:25.032');
/*!40000 ALTER TABLE `referralcode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report`
--

DROP TABLE IF EXISTS `report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report` (
  `id` varchar(191) NOT NULL,
  `reporterId` varchar(191) NOT NULL,
  `targetType` enum('LISTING','USER','MESSAGE') NOT NULL,
  `targetId` varchar(191) NOT NULL,
  `reason` enum('SCAM','FAKE_ACCOUNT','INAPPROPRIATE_CONTENT','SPAM','HARASSMENT','OTHER') NOT NULL,
  `details` text DEFAULT NULL,
  `status` enum('PENDING','REVIEWING','RESOLVED','DISMISSED') NOT NULL DEFAULT 'PENDING',
  `resolutionAction` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `resolvedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Report_status_idx` (`status`),
  KEY `Report_targetType_targetId_idx` (`targetType`,`targetId`),
  KEY `Report_reporterId_fkey` (`reporterId`),
  CONSTRAINT `Report_reporterId_fkey` FOREIGN KEY (`reporterId`) REFERENCES `user` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report`
--

LOCK TABLES `report` WRITE;
/*!40000 ALTER TABLE `report` DISABLE KEYS */;
INSERT INTO `report` VALUES ('cmrzjtfrs000385gbd9zrogi4','cmrzfl9fa000011acdi1d6g3f','USER','cmrz6qkfk000mvs869uavrwi6','HARASSMENT','Non','RESOLVED',NULL,'2026-07-24 23:05:35.512','2026-07-24 23:06:09.039');
/*!40000 ALTER TABLE `report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `review` (
  `id` varchar(191) NOT NULL,
  `escrowId` varchar(191) NOT NULL,
  `reviewerId` varchar(191) NOT NULL,
  `revieweeId` varchar(191) NOT NULL,
  `rating` int(11) NOT NULL,
  `comment` text DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `Review_escrowId_reviewerId_key` (`escrowId`,`reviewerId`),
  KEY `Review_revieweeId_idx` (`revieweeId`),
  KEY `Review_reviewerId_fkey` (`reviewerId`),
  CONSTRAINT `Review_escrowId_fkey` FOREIGN KEY (`escrowId`) REFERENCES `escrow` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `Review_revieweeId_fkey` FOREIGN KEY (`revieweeId`) REFERENCES `user` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `Review_reviewerId_fkey` FOREIGN KEY (`reviewerId`) REFERENCES `user` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `riskscore`
--

DROP TABLE IF EXISTS `riskscore`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `riskscore` (
  `id` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `score` int(11) NOT NULL DEFAULT 0,
  `severity` enum('LOW','MEDIUM','HIGH','CRITICAL') NOT NULL DEFAULT 'LOW',
  `factors` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`factors`)),
  `computedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `dismissedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `RiskScore_userId_key` (`userId`),
  KEY `RiskScore_score_idx` (`score`),
  KEY `RiskScore_severity_idx` (`severity`),
  CONSTRAINT `RiskScore_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `riskscore`
--

LOCK TABLES `riskscore` WRITE;
/*!40000 ALTER TABLE `riskscore` DISABLE KEYS */;
INSERT INTO `riskscore` VALUES ('cms0xjuwh0004myn5pnf6ne2f','cms0xju3j0002myn5c030pq5v',0,'LOW','[]','2026-07-25 22:17:49.359',NULL),('cms0ymmrv000dmyn5y5s54wnu','cms0ymm5k000bmyn548rcf99h',0,'LOW','[]','2026-07-25 22:47:58.409',NULL);
/*!40000 ALTER TABLE `riskscore` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `savedsearch`
--

DROP TABLE IF EXISTS `savedsearch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `savedsearch` (
  `id` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `filters` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`filters`)),
  `alertEnabled` tinyint(1) NOT NULL DEFAULT 0,
  `lastNotifiedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `SavedSearch_userId_idx` (`userId`),
  CONSTRAINT `SavedSearch_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `savedsearch`
--

LOCK TABLES `savedsearch` WRITE;
/*!40000 ALTER TABLE `savedsearch` DISABLE KEYS */;
/*!40000 ALTER TABLE `savedsearch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `securityflag`
--

DROP TABLE IF EXISTS `securityflag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `securityflag` (
  `id` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `source` varchar(191) NOT NULL,
  `severity` enum('LOW','MEDIUM','HIGH','CRITICAL') NOT NULL DEFAULT 'MEDIUM',
  `reason` text NOT NULL,
  `resolvedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `SecurityFlag_userId_idx` (`userId`),
  KEY `SecurityFlag_severity_resolvedAt_idx` (`severity`,`resolvedAt`),
  CONSTRAINT `SecurityFlag_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `securityflag`
--

LOCK TABLES `securityflag` WRITE;
/*!40000 ALTER TABLE `securityflag` DISABLE KEYS */;
/*!40000 ALTER TABLE `securityflag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session`
--

DROP TABLE IF EXISTS `session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `session` (
  `id` varchar(191) NOT NULL,
  `sessionToken` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `expires` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Session_sessionToken_key` (`sessionToken`),
  KEY `Session_userId_idx` (`userId`),
  CONSTRAINT `Session_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session`
--

LOCK TABLES `session` WRITE;
/*!40000 ALTER TABLE `session` DISABLE KEYS */;
/*!40000 ALTER TABLE `session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staffinvite`
--

DROP TABLE IF EXISTS `staffinvite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staffinvite` (
  `id` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `staffRoleId` varchar(191) DEFAULT NULL,
  `invitedById` varchar(191) NOT NULL,
  `expiresAt` datetime(3) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `StaffInvite_email_key` (`email`),
  KEY `StaffInvite_email_idx` (`email`),
  KEY `StaffInvite_staffRoleId_fkey` (`staffRoleId`),
  KEY `StaffInvite_invitedById_fkey` (`invitedById`),
  CONSTRAINT `StaffInvite_invitedById_fkey` FOREIGN KEY (`invitedById`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `StaffInvite_staffRoleId_fkey` FOREIGN KEY (`staffRoleId`) REFERENCES `staffrole` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staffinvite`
--

LOCK TABLES `staffinvite` WRITE;
/*!40000 ALTER TABLE `staffinvite` DISABLE KEYS */;
/*!40000 ALTER TABLE `staffinvite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staffrole`
--

DROP TABLE IF EXISTS `staffrole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staffrole` (
  `id` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `permissions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`permissions`)),
  `isSystem` tinyint(1) NOT NULL DEFAULT 0,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `description` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `StaffRole_name_key` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staffrole`
--

LOCK TABLES `staffrole` WRITE;
/*!40000 ALTER TABLE `staffrole` DISABLE KEYS */;
/*!40000 ALTER TABLE `staffrole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscriptionplan`
--

DROP TABLE IF EXISTS `subscriptionplan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscriptionplan` (
  `id` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `priceMonthly` decimal(12,2) NOT NULL,
  `listingLimit` int(11) NOT NULL,
  `escrowFeeRate` double NOT NULL,
  `minFee` decimal(12,2) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `badge` varchar(191) DEFAULT NULL,
  `color` varchar(191) NOT NULL DEFAULT '#6366f1',
  `description` text DEFAULT NULL,
  `displayName` varchar(191) DEFAULT NULL,
  `features` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`features`)),
  `isActive` tinyint(1) NOT NULL DEFAULT 1,
  `isPopular` tinyint(1) NOT NULL DEFAULT 0,
  `maxEscrows` int(11) NOT NULL DEFAULT 0,
  `priceAnnual` decimal(12,2) DEFAULT NULL,
  `sortOrder` int(11) NOT NULL DEFAULT 0,
  `trialDays` int(11) NOT NULL DEFAULT 0,
  `updatedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `SubscriptionPlan_name_key` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriptionplan`
--

LOCK TABLES `subscriptionplan` WRITE;
/*!40000 ALTER TABLE `subscriptionplan` DISABLE KEYS */;
INSERT INTO `subscriptionplan` VALUES ('cmrxycond0000pnrdp6petwcy','FREE',0.00,5,0.05,4.00,'2026-07-23 20:16:55.753',NULL,'#6366f1',NULL,NULL,'[]',1,0,0,NULL,0,0,'2026-07-24 17:29:11.539'),('cmrxyconj0001pnrd0x3ysam0','STARTER',6.00,20,0.04,3.00,'2026-07-23 20:16:55.759',NULL,'#6366f1',NULL,NULL,'[]',1,0,0,NULL,0,0,'2026-07-24 17:29:11.539'),('cmrxycont0002pnrdr7ch00i0','PRO',15.00,75,0.03,2.00,'2026-07-23 20:16:55.770',NULL,'#6366f1',NULL,NULL,'[]',1,0,0,NULL,0,0,'2026-07-24 17:29:11.539'),('cmrxyconx0003pnrd97eeb5g1','ENTERPRISE',30.00,999,0.02,1.00,'2026-07-23 20:16:55.774',NULL,'#6366f1',NULL,NULL,'[]',1,0,0,NULL,0,0,'2026-07-24 17:29:11.539');
/*!40000 ALTER TABLE `subscriptionplan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `termsacceptance`
--

DROP TABLE IF EXISTS `termsacceptance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `termsacceptance` (
  `id` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `version` varchar(191) NOT NULL,
  `acceptedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `ip` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `TermsAcceptance_userId_version_key` (`userId`,`version`),
  KEY `TermsAcceptance_userId_idx` (`userId`),
  CONSTRAINT `TermsAcceptance_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `termsacceptance`
--

LOCK TABLES `termsacceptance` WRITE;
/*!40000 ALTER TABLE `termsacceptance` DISABLE KEYS */;
INSERT INTO `termsacceptance` VALUES ('cmry9ak8c0005gkzeg1q1fhof','cmrxycp3w0007pnrdv1agkll3','2.5','2026-07-24 01:23:16.021','::1'),('cmrz6qotn000svs86eq9qzfvq','cmrz6qkfk000mvs869uavrwi6','2.5','2026-07-24 16:59:32.267','92.96.11.80'),('cmrzflcei000611accpkx910i','cmrzfl9fa000011acdi1d6g3f','2.5','2026-07-24 21:07:19.435','92.96.11.80'),('cmrzkv65q000c85gbxyyiayz9','cmrzkv4or000685gbijzeqlym','2.5','2026-07-24 23:34:55.982','92.96.11.80');
/*!40000 ALTER TABLE `termsacceptance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction` (
  `id` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `type` enum('DEPOSIT','WITHDRAWAL','ESCROW_PAYMENT','ESCROW_RELEASE','PLATFORM_FEE','REFUND','WALLET_CREDIT','WALLET_DEBIT','PROMOTION','BUMP','SUBSCRIPTION') NOT NULL,
  `status` enum('PENDING','COMPLETED','FAILED','CANCELLED') NOT NULL DEFAULT 'PENDING',
  `amount` decimal(12,2) NOT NULL,
  `balanceBefore` decimal(12,2) NOT NULL,
  `balanceAfter` decimal(12,2) NOT NULL,
  `escrowId` varchar(191) DEFAULT NULL,
  `cryptoPaymentId` varchar(191) DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `Transaction_cryptoPaymentId_key` (`cryptoPaymentId`),
  KEY `Transaction_userId_type_idx` (`userId`,`type`),
  KEY `Transaction_status_idx` (`status`),
  KEY `Transaction_escrowId_fkey` (`escrowId`),
  CONSTRAINT `Transaction_escrowId_fkey` FOREIGN KEY (`escrowId`) REFERENCES `escrow` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Transaction_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction`
--

LOCK TABLES `transaction` WRITE;
/*!40000 ALTER TABLE `transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `twofactorauth`
--

DROP TABLE IF EXISTS `twofactorauth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `twofactorauth` (
  `id` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `secret` varchar(191) NOT NULL,
  `backupCodes` text NOT NULL,
  `enabledAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `TwoFactorAuth_userId_key` (`userId`),
  CONSTRAINT `TwoFactorAuth_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `twofactorauth`
--

LOCK TABLES `twofactorauth` WRITE;
/*!40000 ALTER TABLE `twofactorauth` DISABLE KEYS */;
INSERT INTO `twofactorauth` VALUES ('cmry5a3160008j7huwmwy10e3','cmrxycp3p0005pnrdzzoawa9h','78911068d4e654b000af7e78:0a5e56f6d3165e56e30d1bf0640867b6:8ad167371029368fbf8a964f9f9750ca38d757ed53137cc150ebda2105498fe4','[\"$2a$10$PLOTmeEXoIiYM10kXtfequ10cweuVwl6EgL0wuWS9PG7hgJaH9X8y\",\"$2a$10$0WkN8nrIFzHDBzck1sTnh.P9AYlV5cbKLjElCiQ5d0ztNdRcq3EdK\",\"$2a$10$qGeD2nu0rKBf/z9uY0I27er3sgBvXCpVuZGSw7Gsf9a1I1q.G/ZWG\",\"$2a$10$qk1yWcByiSey3pqj.jJ0BuGsbF1LkVEW8SHPzRgl9V.QpLBXBzQX.\",\"$2a$10$OQOnCPdqgqw0Xw3ieFiGEO.mR0nfucF1lEFepBh26jCBxOfhZpYIS\",\"$2a$10$XIRGE2gqj6AMvsJrn3AKkenANQWr/LlLmGWvGnEIfO1OKinEuWydG\",\"$2a$10$oKQhYgP0TZEvjhYpR.KwxurTtwLhRxeSh4a46zP/rcXVsus7YR/oK\",\"$2a$10$hbKXeIQQdMcPkAXdo9nug.hbxIWE1xmmHGmyD2cy6vsmXd5V7JtIa\",\"$2a$10$u7A4ilW9R5/NzJ2NJDZpi.tB6QT7gx1eFlK2TI1raDohx1fG6vt6q\",\"$2a$10$IYQvEbkaYJQiOkzd3AqQ9eh3.VLEmdKlrtgZ1hOOSxbbwPOLOdx..\"]','2026-07-23 23:31:44.424');
/*!40000 ALTER TABLE `twofactorauth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `emailVerified` datetime(3) DEFAULT NULL,
  `password` varchar(191) DEFAULT NULL,
  `name` varchar(191) DEFAULT NULL,
  `username` varchar(191) DEFAULT NULL,
  `image` varchar(191) DEFAULT NULL,
  `role` enum('USER','ADMIN') NOT NULL DEFAULT 'USER',
  `kycLevel` enum('NONE','EMAIL','PHONE','ID_VERIFIED') NOT NULL DEFAULT 'NONE',
  `verifiedBadge` enum('NONE','BLUE','GOLD','GREY','OFFICIAL') NOT NULL DEFAULT 'NONE',
  `trustScore` int(11) NOT NULL DEFAULT 0,
  `walletBalance` decimal(12,2) NOT NULL DEFAULT 0.00,
  `subscriptionPlanId` varchar(191) DEFAULT NULL,
  `subscriptionExpiresAt` datetime(3) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `socialLinks` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`socialLinks`)),
  `isBanned` tinyint(1) NOT NULL DEFAULT 0,
  `bannedReason` varchar(191) DEFAULT NULL,
  `lastSeenAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `displayCurrency` varchar(191) NOT NULL DEFAULT 'USD',
  `referralCookie` varchar(191) DEFAULT NULL,
  `countryCode` varchar(2) DEFAULT NULL,
  `primaryIntent` enum('BUYER','SELLER','BOTH') DEFAULT NULL,
  `sellIntentPlatforms` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`sellIntentPlatforms`)),
  `sellReason` enum('NO_LONGER_NEEDED','FUNDING_NEW_PROJECT','DIVERSIFYING','OTHER') DEFAULT NULL,
  `onboardingCompletedAt` datetime(3) DEFAULT NULL,
  `notifPrefs` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`notifPrefs`)),
  `staffRoleId` varchar(191) DEFAULT NULL,
  `expoPushToken` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `User_email_key` (`email`),
  UNIQUE KEY `User_username_key` (`username`),
  KEY `User_role_idx` (`role`),
  KEY `User_subscriptionPlanId_fkey` (`subscriptionPlanId`),
  KEY `User_staffRoleId_fkey` (`staffRoleId`),
  CONSTRAINT `User_staffRoleId_fkey` FOREIGN KEY (`staffRoleId`) REFERENCES `staffrole` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `User_subscriptionPlanId_fkey` FOREIGN KEY (`subscriptionPlanId`) REFERENCES `subscriptionplan` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('cmrxycp3p0005pnrdzzoawa9h','admin@accsmarkets.org','2026-07-23 20:16:56.339','$2a$12$8C6tnQpehDf6FJc1v7WpjuOdOKpcaPmw9vzLpeOb.yhIEGXI/UedC','Platform Admin','admin','https://res.cloudinary.com/ay5pafey/image/upload/v1784850880/accsmarkets/avatars/gvbw4t9agtdmrt8d9qe7.png','ADMIN','ID_VERIFIED','GOLD',100,5000.00,'cmrxyconx0003pnrd97eeb5g1',NULL,'','{}',0,NULL,'2026-07-24 00:18:14.613','2025-07-23 20:16:56.339','2026-07-24 00:18:14.614','USD',NULL,'US',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('cmrxycp3w0007pnrdv1agkll3','support@accsmarkets.org','2026-07-23 20:16:56.347','$2a$12$8C6tnQpehDf6FJc1v7WpjuOdOKpcaPmw9vzLpeOb.yhIEGXI/UedC','AccsMarkets Support','support','https://res.cloudinary.com/ay5pafey/image/upload/v1784850253/accsmarkets/avatars/xcqyv9o6cnpukypjgeim.png','ADMIN','ID_VERIFIED','OFFICIAL',100,0.00,'cmrxycond0000pnrdp6petwcy',NULL,'','{}',0,NULL,'2026-07-26 13:43:31.292','2025-07-23 20:16:56.347','2026-07-26 13:43:31.298','USD',NULL,'US',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('cmrz6qkfk000mvs869uavrwi6','americanhistory921@gmail.com','2026-07-24 18:00:07.288',NULL,'American History','maliknain','https://lh3.googleusercontent.com/a/ACg8ocINkmTqb5qNoJeORCq3N8ThZAD2tEF6ELag2wVL7gT5BF-7l58=s96-c','USER','ID_VERIFIED','NONE',0,0.00,'cmrxycond0000pnrdp6petwcy',NULL,'Best Seller','{}',0,NULL,'2026-07-26 22:56:36.711','2026-07-24 16:59:26.576','2026-07-26 22:56:36.725','USD',NULL,'AE','BOTH','[\"YOUTUBE\"]','NO_LONGER_NEEDED','2026-07-24 19:32:05.741',NULL,NULL,NULL),('cmrzfl9fa000011acdi1d6g3f','zulqarnainpervaiz222@gmail.com',NULL,NULL,'Zulqarnain Pervaiz',NULL,'https://lh3.googleusercontent.com/a/ACg8ocI_DBIQhrc65fRvmb3zfwMnmGK3bSPjvB7qh8EIXfBxuMz04RG_=s96-c','USER','NONE','NONE',0,0.00,NULL,NULL,NULL,NULL,0,NULL,'2026-07-26 01:20:40.477','2026-07-24 21:07:15.574','2026-07-26 01:20:40.520','USD',NULL,'PK','BOTH','[\"YOUTUBE\",\"TIKTOK\",\"FACEBOOK\"]','NO_LONGER_NEEDED','2026-07-24 21:07:33.846',NULL,NULL,NULL),('cmrzkv4or000685gbijzeqlym','cmcelmo@gmail.com',NULL,NULL,'Cheryl Coffey',NULL,'https://lh3.googleusercontent.com/a/ACg8ocKzqql0pvN6mRnkSK0D9aJCYNkt_0SkKEaRkT0sZkKv_w_oPIWoqw=s96-c','USER','NONE','NONE',0,0.00,NULL,NULL,NULL,NULL,0,NULL,'2026-07-25 22:15:44.808','2026-07-24 23:34:54.075','2026-07-25 22:15:44.811','USD',NULL,'US','BOTH','[\"YOUTUBE\"]','NO_LONGER_NEEDED','2026-07-24 23:35:06.272',NULL,NULL,NULL),('cms0xju3j0002myn5c030pq5v','nain@accsmarkets.org','2026-07-25 22:18:01.074','$2a$12$kNCSElIcXFhZY7AStfpazONbpB6fXIER2LltqyQXn8Nd7OoVd2o/K','Apple User','nain',NULL,'USER','EMAIL','NONE',0,0.00,'cmrxycond0000pnrdp6petwcy',NULL,NULL,NULL,0,NULL,NULL,'2026-07-25 22:17:48.319','2026-07-25 22:18:01.081','USD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('cms0ymm5k000bmyn548rcf99h','maliknain162@gmail.com',NULL,'$2a$12$JlZtCiEtuHP/NwCAAVbb1OPQwlMstvyjrs4qAFlWonT49NCmCitf.','Zulqarnain','maliknain162',NULL,'USER','NONE','NONE',0,0.00,'cmrxycond0000pnrdp6petwcy',NULL,NULL,NULL,0,NULL,NULL,'2026-07-25 22:47:57.608','2026-07-25 22:47:57.608','USD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userachievementbadge`
--

DROP TABLE IF EXISTS `userachievementbadge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userachievementbadge` (
  `id` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `badge` enum('RISING_STAR','POWER_SELLER','TOP_SELLER','LEGEND','BIG_EARNER','WHALE','FIVE_STAR_SELLER','FAST_RESPONDER','TRUSTED_SELLER') NOT NULL,
  `awardedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `UserAchievementBadge_userId_badge_key` (`userId`,`badge`),
  KEY `UserAchievementBadge_userId_idx` (`userId`),
  CONSTRAINT `UserAchievementBadge_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userachievementbadge`
--

LOCK TABLES `userachievementbadge` WRITE;
/*!40000 ALTER TABLE `userachievementbadge` DISABLE KEYS */;
INSERT INTO `userachievementbadge` VALUES ('cmrxycpbr003tpnrda4rk8xjh','cmrxycp4b000bpnrdeuregzht','POWER_SELLER','2026-05-24 20:16:56.631'),('cmrxycpbr003upnrdk3nc3cyh','cmrxycp4b000bpnrdeuregzht','TRUSTED_SELLER','2026-04-24 20:16:56.631'),('cmrxycpbr003vpnrd0mdv4sxe','cmrxycp4b000bpnrdeuregzht','FIVE_STAR_SELLER','2026-06-23 20:16:56.631'),('cmrxycpbr003wpnrdnu69rdkt','cmrxycp450009pnrdyp431c8c','RISING_STAR','2026-03-25 20:16:56.631'),('cmrxycpbr003xpnrdeankmfif','cmrxycp450009pnrdyp431c8c','FAST_RESPONDER','2026-05-24 20:16:56.631'),('cmrxycpbr003ypnrdh2pxcn0d','cmrxycp4p000hpnrdz8h82h1c','RISING_STAR','2026-07-03 20:16:56.631');
/*!40000 ALTER TABLE `userachievementbadge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userfollow`
--

DROP TABLE IF EXISTS `userfollow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userfollow` (
  `id` varchar(191) NOT NULL,
  `followerId` varchar(191) NOT NULL,
  `followingId` varchar(191) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `UserFollow_followerId_followingId_key` (`followerId`,`followingId`),
  KEY `UserFollow_followingId_idx` (`followingId`),
  CONSTRAINT `UserFollow_followerId_fkey` FOREIGN KEY (`followerId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `UserFollow_followingId_fkey` FOREIGN KEY (`followingId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userfollow`
--

LOCK TABLES `userfollow` WRITE;
/*!40000 ALTER TABLE `userfollow` DISABLE KEYS */;
/*!40000 ALTER TABLE `userfollow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verificationtoken`
--

DROP TABLE IF EXISTS `verificationtoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `verificationtoken` (
  `identifier` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `expires` datetime(3) NOT NULL,
  UNIQUE KEY `VerificationToken_token_key` (`token`),
  UNIQUE KEY `VerificationToken_identifier_token_key` (`identifier`,`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verificationtoken`
--

LOCK TABLES `verificationtoken` WRITE;
/*!40000 ALTER TABLE `verificationtoken` DISABLE KEYS */;
INSERT INTO `verificationtoken` VALUES ('maliknain162@gmail.com','3835fe23-e258-4ed6-ab95-ae6a19e4ccc3','2026-07-26 22:47:57.618');
/*!40000 ALTER TABLE `verificationtoken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wantedlisting`
--

DROP TABLE IF EXISTS `wantedlisting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wantedlisting` (
  `id` varchar(191) NOT NULL,
  `buyerId` varchar(191) NOT NULL,
  `platform` enum('YOUTUBE','INSTAGRAM','TIKTOK','FACEBOOK','TELEGRAM','TWITTER_X','SNAPCHAT','PINTEREST','LINKEDIN','WEBSITE') DEFAULT NULL,
  `title` varchar(191) NOT NULL,
  `criteria` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`criteria`)),
  `budget` decimal(12,2) DEFAULT NULL,
  `status` enum('OPEN','FULFILLED','CLOSED') NOT NULL DEFAULT 'OPEN',
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `WantedListing_buyerId_status_idx` (`buyerId`,`status`),
  KEY `WantedListing_platform_status_idx` (`platform`,`status`),
  CONSTRAINT `WantedListing_buyerId_fkey` FOREIGN KEY (`buyerId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wantedlisting`
--

LOCK TABLES `wantedlisting` WRITE;
/*!40000 ALTER TABLE `wantedlisting` DISABLE KEYS */;
/*!40000 ALTER TABLE `wantedlisting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `watchlist`
--

DROP TABLE IF EXISTS `watchlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `watchlist` (
  `id` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `listingId` varchar(191) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `Watchlist_userId_listingId_key` (`userId`,`listingId`),
  KEY `Watchlist_userId_idx` (`userId`),
  KEY `Watchlist_listingId_fkey` (`listingId`),
  CONSTRAINT `Watchlist_listingId_fkey` FOREIGN KEY (`listingId`) REFERENCES `listing` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Watchlist_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `watchlist`
--

LOCK TABLES `watchlist` WRITE;
/*!40000 ALTER TABLE `watchlist` DISABLE KEYS */;
/*!40000 ALTER TABLE `watchlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhookdelivery`
--

DROP TABLE IF EXISTS `webhookdelivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webhookdelivery` (
  `id` varchar(191) NOT NULL,
  `endpointId` varchar(191) NOT NULL,
  `eventType` enum('ESCROW_CREATED','ESCROW_FUNDED','ESCROW_COMPLETED','ESCROW_DISPUTED','OFFER_RECEIVED','OFFER_ACCEPTED','LISTING_SOLD','PAYMENT_RECEIVED') NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`payload`)),
  `status` enum('PENDING','SUCCESS','FAILED') NOT NULL DEFAULT 'PENDING',
  `responseStatus` int(11) DEFAULT NULL,
  `responseBody` text DEFAULT NULL,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `nextRetryAt` datetime(3) DEFAULT NULL,
  `deliveredAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `WebhookDelivery_endpointId_idx` (`endpointId`),
  KEY `WebhookDelivery_status_idx` (`status`),
  CONSTRAINT `WebhookDelivery_endpointId_fkey` FOREIGN KEY (`endpointId`) REFERENCES `webhookendpoint` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhookdelivery`
--

LOCK TABLES `webhookdelivery` WRITE;
/*!40000 ALTER TABLE `webhookdelivery` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhookdelivery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhookendpoint`
--

DROP TABLE IF EXISTS `webhookendpoint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webhookendpoint` (
  `id` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `url` varchar(191) NOT NULL,
  `secret` varchar(191) NOT NULL,
  `events` varchar(191) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `WebhookEndpoint_userId_idx` (`userId`),
  CONSTRAINT `WebhookEndpoint_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhookendpoint`
--

LOCK TABLES `webhookendpoint` WRITE;
/*!40000 ALTER TABLE `webhookendpoint` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhookendpoint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'accsmarkets'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-27  3:00:03
